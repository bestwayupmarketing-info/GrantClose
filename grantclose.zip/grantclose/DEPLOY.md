# Deploying GrantClose (cheaply)

GrantClose has three deployable pieces:

1. **API** (Python/FastAPI) — needs a always-on host.
2. **Database** (MongoDB) — free tier is plenty.
3. **Web frontend** — a static bundle; host it anywhere static.

Total typical cost: **$0–7/month**. Pick one path below.

---

## Path A — Docker Compose on any VPS (simplest full control)

Cheapest long-term: an Oracle Cloud **Always Free** VM (4 ARM cores, 24 GB RAM — overkill,
free forever) or a $4–6/mo Hetzner/DigitalOcean droplet.

```bash
git clone <your-repo> && cd grantclose
docker compose up -d --build
```

Open `http://<server-ip>:8001`. Put Caddy or nginx in front for HTTPS (or use `caddy` with a
one-liner config). Set `PUBLIC_BASE_URL=https://your-domain` and a strong `JWT_SECRET`.

Backups: snapshot the `mongo_data` and `uploads` volumes.

---

## Path B — Managed free tiers (zero server admin)

### 1. MongoDB (free)
- [MongoDB Atlas](https://www.mongodb.com/atlas) → M0 shared cluster, free.
- Create a database user, allow network access, copy the connection string.

### 2. API on Render free tier (or Fly.io)
- Push this repo to GitHub.
- [Render](https://render.com) → New → **Web Service** → pick the repo.
  - Root directory: `backend`
  - Build: `pip install -r requirements.txt`
  - Start: `uvicorn server:app --host 0.0.0.0 --port $PORT`
  - Environment: `MONGO_URL=<atlas string>`, `JWT_SECRET=<random 64 chars>`,
    `PUBLIC_BASE_URL=https://your-api.onrender.com`
- Note: free tier spins down on inactivity (first request ~30 s). Render's $7/mo tier stays warm.

### 3. Web frontend on Cloudflare Pages / Netlify (free)
```bash
cd frontend
npm install
EXPO_PUBLIC_API_URL=https://your-api.onrender.com npm run export:web
```
- Upload the `dist/` folder to **Cloudflare Pages** or **Netlify** (drag-and-drop works).
- Done: the static site talks to your API.

---

## Path C — All-in-one Dockerfile (single container)

Good for Railway, Fly.io, or a NAS:

```bash
docker build -t grantclose .
docker run -d -p 8001:8001 \
  -e MONGO_URL=mongodb+srv://... -e JWT_SECRET=... \
  -v grantclose_uploads:/data/uploads \
  grantclose
```

The image builds the web export and serves it from the API process — one port, one container.

---

## After deploying

1. Visit the site → **Create account**.
2. Create a grant with its approved categories.
3. Log an expense with a receipt photo.
4. Open the grant → **Report** → *Print / Save as PDF* — that's your closeout package.

## Optional power-ups

| Want | Set |
|------|-----|
| Email report links | `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS` (any SMTP provider; Gmail needs an app password) |
| AI report narrative | `AI_API_KEY` (+ `AI_BASE_URL`/`AI_MODEL` for OpenAI-compatible providers) |
| Mobile app | `npm start` in `frontend/`, scan the QR with Expo Go — point it at your API with `EXPO_PUBLIC_API_URL` in `frontend/.env` |

## Security checklist

- [ ] Strong random `JWT_SECRET`
- [ ] HTTPS in front (Caddy/nginx/Cloudflare)
- [ ] Atlas IP allowlist restricted to your API host
- [ ] Regular backup of DB + `/data/uploads` (receipt photos)
