# GrantClose

Simple grant reporting for small nonprofits, school clubs, community organizations, and church
ministries. Create a grant, set its approved budget, snap receipt photos, record project
outcomes, and generate a funder-ready closeout report.

Self-hosted, open code, no per-seat pricing — the whole thing typically costs **$0–7/month**
to run (see DEPLOY.md).

## Stack

| Layer    | Tech                                                        |
|----------|-------------------------------------------------------------|
| Backend  | Python 3.12 · FastAPI · MongoDB (motor) · JWT auth           |
| Frontend | Expo + expo-router (TypeScript) — web export + iOS/Android   |
| Reports  | Printable HTML closeout report (Save-as-PDF from the browser) |
| Optional | SMTP email sharing · OpenAI-compatible report narratives      |

## Quick start (local dev)

Terminal 1 — API (needs a local MongoDB, or use `docker compose up mongo`):

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

Terminal 2 — app:

```bash
cd frontend
cp .env.example .env      # points at http://localhost:8001
npm install
npm run web               # web preview
# or: npm start           # + Expo Go on your phone
```

## One-container run (easiest)

```bash
docker compose up -d --build
# open http://localhost:8001
```

## Project layout

```
backend/    FastAPI service (server.py holds the routes; core.py the plumbing)
frontend/   Expo app — routes in app/, shared code in src/ and constants/
DEPLOY.md   Step-by-step hosting guides for the cheapest options
Dockerfile  All-in-one image (frontend export + API)
docker-compose.yml  App + MongoDB with persistent volumes
```

## Features

- **Grants & budgets** — award amount plus approved categories; live spent/remaining per category.
- **Expenses with receipts** — attach receipt photos (camera roll on mobile, file picker on web);
  all receipts collected under Documents.
- **Outcomes** — titles, stories, and metrics (e.g. *200 books*).
- **Closeout report** — one printable page: budget vs. actual, expense ledger, outcomes; Save as
  PDF straight from the browser.
- **AI narrative (optional)** — 2–3 draft paragraphs for the cover email; falls back to a
  built-in template when no AI key is configured.
- **Share by email (optional)** — emails a report link via your own SMTP.

## Configuration

All backend configuration is via environment variables — see `backend/.env.example`.
Nothing phones home; the only possible outbound calls are the SMTP and AI endpoints you
explicitly configure.
