"""Optional AI narrative for closeout reports.

Uses any OpenAI-compatible chat endpoint when AI_API_KEY is set; otherwise
falls back to a built-in template so the feature always works.
"""
from __future__ import annotations

import httpx

import reports_gen
from core import settings

PROMPT = """You write funder-facing grant closeout narratives for small nonprofits.
Write 2-3 concise paragraphs summarizing grant performance based on the data below.
Tone: factual, warm, no jargon, no bullet points. Mention budget adherence and outcomes.

{data}"""


async def write_summary(bundle: dict) -> str:
    digest = reports_gen.plain_summary(bundle)
    outcomes = "\n".join(
        f"- {o['title']}: {o.get('detail', '')}" for o in bundle["outcomes"]
    )
    data = f"{digest}\n\nOutcomes:\n{outcomes or '(none recorded)'}"

    if settings.ai_api_key:
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                r = await client.post(
                    f"{settings.ai_base_url.rstrip('/')}/chat/completions",
                    headers={"Authorization": f"Bearer {settings.ai_api_key}"},
                    json={
                        "model": settings.ai_model,
                        "messages": [
                            {"role": "system", "content": PROMPT.format(data=data)},
                            {"role": "user", "content": "Write the narrative."},
                        ],
                        "temperature": 0.4,
                    },
                )
                r.raise_for_status()
                return r.json()["choices"][0]["message"]["content"].strip()
        except Exception:
            pass  # fall through to template

    g = bundle["grant"]
    s = bundle["summary"]
    pct = (
        f"{(s['total_spent'] / s['total_budgeted'] * 100):.0f}%"
        if s["total_budgeted"]
        else "n/a"
    )
    lines = [
        f"During the grant period, {bundle['user'].get('org_name') or bundle['user']['name']} "
        f"implemented \"{g['name']}\""
        + (f" with support from {g['funder']}." if g.get("funder") else "."),
        f"Of the ${s['total_budgeted']:,.2f} award, ${s['total_spent']:,.2f} "
        f"({pct}) was spent across {len(s['categories'])} budget categories, "
        f"leaving ${s['total_remaining']:,.2f} unspent. "
        f"{len(bundle['expenses'])} expenses were documented with receipts.",
    ]
    if bundle["outcomes"]:
        lines.append(
            "Key outcomes: "
            + "; ".join(o["title"] for o in bundle["outcomes"][:5])
            + "."
        )
    lines.append("All reporting materials are attached to this closeout package.")
    return "\n\n".join(lines)
