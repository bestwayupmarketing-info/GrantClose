"""Core plumbing: settings, Mongo connection, auth, serializers."""
from __future__ import annotations

import os
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import bcrypt
import jwt
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    mongo_url: str = "mongodb://localhost:27017"
    mongo_db: str = "grantclose"
    jwt_secret: str = "change-me"
    jwt_expires_days: int = 30
    cors_origins: str = "*"
    upload_dir: str = "./uploads"
    public_base_url: str = "http://localhost:8001"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_pass: str = ""
    smtp_from: str = "GrantClose <no-reply@grantclose.app>"
    ai_base_url: str = "https://api.openai.com/v1"
    ai_api_key: str = ""
    ai_model: str = "gpt-4o-mini"


settings = Settings()

_client: Optional[AsyncIOMotorClient] = None


def get_db() -> AsyncIOMotorDatabase:
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(settings.mongo_url)
    return _client[settings.mongo_db]


bearer = HTTPBearer(auto_error=False)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------------------------------------------------------------- schemas ---

class RegisterIn(BaseModel):
    email: str
    password: str = Field(min_length=8)
    name: str = Field(min_length=1, max_length=120)
    org_name: str = ""


class LoginIn(BaseModel):
    email: str
    password: str


class UserOut(BaseModel):
    id: str
    email: str
    name: str
    org_name: str


class CategoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    budgeted: float = Field(ge=0)


class GrantIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    funder: str = ""
    amount_total: float = Field(ge=0)
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    notes: str = ""
    categories: list[CategoryIn] = []


class GrantPatch(BaseModel):
    name: Optional[str] = None
    funder: Optional[str] = None
    amount_total: Optional[float] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    notes: Optional[str] = None
    categories: Optional[list[CategoryIn]] = None
    status: Optional[str] = None


class ExpenseIn(BaseModel):
    category: str = Field(min_length=1, max_length=80)
    amount: float = Field(gt=0)
    date: str
    vendor: str = ""
    description: str = ""


class ExpensePatch(BaseModel):
    category: Optional[str] = None
    amount: Optional[float] = None
    date: Optional[str] = None
    vendor: Optional[str] = None
    description: Optional[str] = None


class OutcomeIn(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    detail: str = ""
    metric_value: Optional[float] = None
    metric_unit: str = ""
    date: Optional[str] = None


class OutcomePatch(BaseModel):
    title: Optional[str] = None
    detail: Optional[str] = None
    metric_value: Optional[float] = None
    metric_unit: Optional[str] = None
    date: Optional[str] = None


class ShareReportIn(BaseModel):
    to: str


# ----------------------------------------------------------------- helpers ---

def new_id() -> str:
    return uuid.uuid4().hex[:24]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False


def make_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(days=settings.jwt_expires_days),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


async def current_user(
    creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
) -> dict:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not signed in")
    try:
        payload = jwt.decode(creds.credentials, settings.jwt_secret, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired session")
    user = await get_db().users.find_one({"_id": payload["sub"]})
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account not found")
    return user


def clean_doc(doc: dict) -> dict:
    doc = dict(doc)
    doc["id"] = doc.pop("_id")
    doc.pop("password_hash", None)
    return doc


def slug_filename(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("_") or "file"
    return f"{new_id()}_{base}"


async def get_owned_grant(grant_id: str, user_id: str) -> dict:
    g = await get_db().grants.find_one({"_id": grant_id, "user_id": user_id})
    if not g:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Grant not found")
    return g


async def grant_summary(grant: dict) -> dict:
    """Spent per category + remaining, for one grant."""
    spent: dict[str, float] = {}
    cur = get_db().expenses.find({"grant_id": grant["_id"]})
    async for e in cur:
        spent[e["category"]] = spent.get(e["category"], 0.0) + float(e["amount"])
    categories = []
    for c in grant.get("categories", []):
        s = round(spent.get(c["name"], 0.0), 2)
        categories.append(
            {
                "name": c["name"],
                "budgeted": c["budgeted"],
                "spent": s,
                "remaining": round(c["budgeted"] - s, 2),
            }
        )
    total_spent = round(sum(spent.values()), 2)
    return {
        "categories": categories,
        "total_budgeted": grant.get("amount_total", 0),
        "total_spent": total_spent,
        "total_remaining": round(grant.get("amount_total", 0) - total_spent, 2),
        "uncategorized_spent": round(
            sum(v for k, v in spent.items() if k not in {c["name"] for c in categories}), 2
        ),
    }


async def ensure_indexes() -> None:
    db = get_db()
    await db.users.create_index("email", unique=True)
    await db.grants.create_index([("user_id", 1), ("created_at", -1)])
    await db.expenses.create_index([("grant_id", 1), ("date", -1)])
    await db.outcomes.create_index([("grant_id", 1), ("date", -1)])
