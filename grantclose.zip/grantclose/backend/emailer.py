"""Optional SMTP email. No-ops cleanly when SMTP is not configured."""
from __future__ import annotations

import smtplib
from email.message import EmailMessage

from core import settings


def _configured() -> bool:
    return bool(settings.smtp_host)


def send_report_link(to: str, grant_name: str, org: str, sender_name: str, report_link: str) -> bool:
    """Email a closeout-report link. Returns False when SMTP isn't configured."""
    if not _configured():
        return False
    msg = EmailMessage()
    msg["Subject"] = f"Closeout report: {grant_name}"
    msg["From"] = settings.smtp_from
    msg["To"] = to
    msg.set_content(
        f"Hi,\n\n"
        f"{sender_name} from {org} shared the closeout report for \"{grant_name}\" "
        f"with you:\n\n"
        f"  {report_link}\n\n"
        f"Open the link to view or print the report.\n\n"
        f"— Sent with GrantClose\n"
    )
    try:
        with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=15) as s:
            if settings.smtp_user:
                s.starttls()
                s.login(settings.smtp_user, settings.smtp_pass)
            s.send_message(msg)
        return True
    except Exception:
        return False
