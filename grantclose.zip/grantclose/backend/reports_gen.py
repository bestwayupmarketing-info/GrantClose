"""Closeout report rendering: printable, funder-ready HTML."""
from __future__ import annotations

from html import escape

from jinja2 import Template

TEMPLATE = Template("""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Closeout Report — {{ grant.name }}</title>
<style>
  :root { color-scheme: light; }
  * { box-sizing: border-box; }
  body { font-family: Georgia, 'Times New Roman', serif; color: #1a2332;
         max-width: 820px; margin: 0 auto; padding: 48px 32px; line-height: 1.55; }
  header { border-bottom: 3px solid #0f766e; padding-bottom: 18px; margin-bottom: 28px; }
  h1 { font-size: 26px; margin: 0 0 4px; }
  .org { color: #475569; font-size: 15px; }
  h2 { font-size: 17px; color: #0f766e; text-transform: uppercase; letter-spacing: .06em;
       margin: 34px 0 10px; border-bottom: 1px solid #cbd5e1; padding-bottom: 5px; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; margin: 8px 0 4px; }
  th, td { text-align: left; padding: 7px 10px; border-bottom: 1px solid #e2e8f0; }
  th { background: #f0fdfa; font-family: -apple-system, sans-serif; font-size: 12px;
       text-transform: uppercase; letter-spacing: .04em; color: #115e59; }
  td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; }
  .totals td { font-weight: 700; border-top: 2px solid #0f766e; border-bottom: none; }
  .meta { display: flex; flex-wrap: wrap; gap: 24px; margin: 14px 0; font-size: 14px; }
  .meta div span { display: block; color: #64748b; font-size: 12px;
                   font-family: -apple-system, sans-serif; text-transform: uppercase; }
  .outcome { margin: 0 0 14px; }
  .outcome b { font-family: -apple-system, sans-serif; }
  .metric { color: #0f766e; font-weight: 600; }
  .note { color: #475569; font-size: 13.5px; }
  .badge { display: inline-block; font-family: -apple-system, sans-serif; font-size: 11px;
           padding: 2px 10px; border-radius: 999px; background: #ccfbf1; color: #115e59;
           text-transform: uppercase; letter-spacing: .05em; }
  .badge.closed { background: #e2e8f0; color: #475569; }
  footer { margin-top: 44px; padding-top: 12px; border-top: 1px solid #cbd5e1;
           color: #64748b; font-size: 12px; font-family: -apple-system, sans-serif; }
  @media print {
    body { padding: 0; max-width: none; }
    .noprint { display: none; }
  }
  .noprint button { font: 600 13px -apple-system, sans-serif; padding: 8px 16px;
                    border-radius: 8px; border: 1px solid #0f766e; background: #0f766e;
                    color: #fff; cursor: pointer; margin-right: 8px; }
</style>
</head>
<body>
<header>
  <div class="org">{{ org }} · GrantClose closeout report</div>
  <h1>{{ grant.name }}</h1>
  <div>
    {% if grant.status == 'closed' %}<span class="badge closed">Closed</span>
    {% else %}<span class="badge">In progress</span>{% endif %}
  </div>
  <div class="meta">
    {% if grant.funder %}<div><span>Funder</span>{{ grant.funder }}</div>{% endif %}
    {% if grant.start_date %}<div><span>Start</span>{{ grant.start_date }}</div>{% endif %}
    {% if grant.end_date %}<div><span>End</span>{{ grant.end_date }}</div>{% endif %}
    <div><span>Total award</span>${{ '%.2f'|format(grant.amount_total) }}</div>
    <div><span>Total spent</span>${{ '%.2f'|format(summary.total_spent) }}</div>
    <div><span>Remaining</span>${{ '%.2f'|format(summary.total_remaining) }}</div>
  </div>
</header>

<div class="noprint" style="margin-bottom:8px">
  <button onclick="window.print()">Print / Save as PDF</button>
  <button style="background:#fff;color:#0f766e" onclick="window.close()">Close</button>
</div>

<h2>Budget vs. actual</h2>
<table>
  <tr><th>Category</th><th class="num">Approved</th><th class="num">Spent</th><th class="num">Remaining</th></tr>
  {% for c in summary.categories %}
  <tr>
    <td>{{ c.name }}</td>
    <td class="num">${{ '%.2f'|format(c.budgeted) }}</td>
    <td class="num">${{ '%.2f'|format(c.spent) }}</td>
    <td class="num">${{ '%.2f'|format(c.remaining) }}</td>
  </tr>
  {% endfor %}
  <tr class="totals">
    <td>Total</td>
    <td class="num">${{ '%.2f'|format(summary.total_budgeted) }}</td>
    <td class="num">${{ '%.2f'|format(summary.total_spent) }}</td>
    <td class="num">${{ '%.2f'|format(summary.total_remaining) }}</td>
  </tr>
</table>

<h2>Expenses ({{ expenses|length }})</h2>
{% if expenses %}
<table>
  <tr><th>Date</th><th>Category</th><th>Vendor</th><th>Description</th><th class="num">Amount</th></tr>
  {% for e in expenses %}
  <tr>
    <td>{{ e.date }}</td>
    <td>{{ e.category }}</td>
    <td>{{ e.vendor }}</td>
    <td>{{ e.description }}</td>
    <td class="num">${{ '%.2f'|format(e.amount) }}</td>
  </tr>
  {% endfor %}
  <tr class="totals"><td colspan="4">Total</td>
    <td class="num">${{ '%.2f'|format(expenses|sum(attribute='amount')) }}</td></tr>
</table>
{% else %}<p class="note">No expenses recorded.</p>{% endif %}

<h2>Project outcomes ({{ outcomes|length }})</h2>
{% for o in outcomes %}
<div class="outcome">
  <b>{{ o.title }}</b>
  {% if o.metric_value is not none %}
    — <span class="metric">{{ o.metric_value }} {{ o.metric_unit }}</span>
  {% endif %}
  <div class="note">{{ o.detail }}</div>
</div>
{% else %}
<p class="note">No outcomes recorded yet.</p>
{% endfor %}

{% if grant.notes %}
<h2>Notes</h2>
<p class="note">{{ grant.notes }}</p>
{% endif %}

<footer>
  Generated by GrantClose on {{ generated_at }} · Contact: {{ contact_email }}
</footer>
</body>
</html>""")


def render_closeout(bundle: dict) -> str:
    from datetime import datetime, timezone

    grant = bundle["grant"]
    user = bundle["user"]
    return TEMPLATE.render(
        grant=grant,
        summary=bundle["summary"],
        expenses=bundle["expenses"],
        outcomes=bundle["outcomes"],
        org=user.get("org_name") or user.get("name") or "",
        contact_email=user.get("email", ""),
        generated_at=datetime.now(timezone.utc).strftime("%B %d, %Y"),
    )


def plain_summary(bundle: dict) -> str:
    """Short text digest used by the AI helper / email body."""
    g = bundle["grant"]
    s = bundle["summary"]
    lines = [
        f"Grant: {g['name']} ({g.get('funder') or 'funder n/a'})",
        f"Award ${s['total_budgeted']:,.2f} · spent ${s['total_spent']:,.2f} "
        f"· remaining ${s['total_remaining']:,.2f}",
        f"{len(bundle['expenses'])} expenses, {len(bundle['outcomes'])} outcomes recorded.",
    ]
    for c in s["categories"]:
        lines.append(f"- {c['name']}: ${c['spent']:,.2f} of ${c['budgeted']:,.2f}")
    return "\n".join(lines)
