"""GrantClose API — FastAPI + MongoDB.

Run locally:  uvicorn server:app --host 0.0.0.0 --port 8001 --reload
"""
from __future__ import annotations

import os
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

import ai
import emailer
import reports_gen
from core import (
    EMAIL_RE,
    ExpenseIn,
    ExpensePatch,
    GrantIn,
    GrantPatch,
    LoginIn,
    OutcomeIn,
    OutcomePatch,
    RegisterIn,
    ShareReportIn,
    bearer,
    clean_doc,
    current_user,
    get_db,
    get_owned_grant,
    grant_summary,
    hash_password,
    make_token,
    new_id,
    now_iso,
    settings,
    slug_filename,
    verify_password,
    ensure_indexes,
)

app = FastAPI(title="GrantClose API", version="1.0.0")

origins = [o.strip() for o in settings.cors_origins.split(",")] or ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs(settings.upload_dir, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=settings.upload_dir), name="uploads")

# Serve the exported Expo web build when it has been placed next to backend/
# (the all-in-one Dockerfile does this). Deep links fall back to index.html.
_DIST = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend_dist"))
if os.path.isdir(_DIST):
    from fastapi.responses import FileResponse

    app.mount("/assets", StaticFiles(directory=os.path.join(_DIST, "assets")), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str):
        if full_path.startswith("api/") or full_path == "api":
            raise HTTPException(404, "Unknown API route")
        candidate = os.path.join(_DIST, full_path)
        if full_path and os.path.isfile(candidate):
            return FileResponse(candidate)
        return FileResponse(os.path.join(_DIST, "index.html"))


@app.on_event("startup")
async def startup() -> None:
    try:
        await ensure_indexes()
    except Exception:  # DB not up yet — retry on first request that needs it
        pass


# ------------------------------------------------------------------- auth ---

@app.post("/api/auth/register")
async def register(body: RegisterIn):
    email = body.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Enter a valid email address")
    db = get_db()
    if await db.users.find_one({"email": email}):
        raise HTTPException(409, "An account with this email already exists")
    user = {
        "_id": new_id(),
        "email": email,
        "name": body.name.strip(),
        "org_name": body.org_name.strip(),
        "password_hash": hash_password(body.password),
        "created_at": now_iso(),
    }
    await db.users.insert_one(user)
    token = make_token(user["_id"])
    return {"token": token, "user": clean_doc(user)}


@app.post("/api/auth/login")
async def login(body: LoginIn):
    user = await get_db().users.find_one({"email": body.email.strip().lower()})
    if not user or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
    return {"token": make_token(user["_id"]), "user": clean_doc(user)}


@app.get("/api/auth/me")
async def me(user: dict = Depends(current_user)):
    return clean_doc(user)


# ------------------------------------------------------------------ grants ---

@app.get("/api/grants")
async def list_grants(user: dict = Depends(current_user)):
    db = get_db()
    out = []
    async for g in db.grants.find({"user_id": user["_id"]}).sort("created_at", -1):
        item = clean_doc(g)
        item["summary"] = await grant_summary(g)
        item.pop("notes", None)
        item.pop("categories", None)
        out.append(item)
    return out


@app.post("/api/grants", status_code=201)
async def create_grant(body: GrantIn, user: dict = Depends(current_user)):
    g = {
        "_id": new_id(),
        "user_id": user["_id"],
        "name": body.name.strip(),
        "funder": body.funder.strip(),
        "amount_total": body.amount_total,
        "start_date": body.start_date,
        "end_date": body.end_date,
        "notes": body.notes,
        "categories": [c.model_dump() for c in body.categories],
        "status": "active",
        "created_at": now_iso(),
    }
    await get_db().grants.insert_one(g)
    return clean_doc(g)


@app.get("/api/grants/{grant_id}")
async def get_grant(grant_id: str, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    out = clean_doc(g)
    out["summary"] = await grant_summary(g)
    return out


@app.patch("/api/grants/{grant_id}")
async def patch_grant(grant_id: str, body: GrantPatch, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    patch = {k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None}
    if "categories" in patch:
        patch["categories"] = [c if isinstance(c, dict) else c.model_dump() for c in patch["categories"]]
    if "status" in patch and patch["status"] not in ("active", "closed"):
        raise HTTPException(422, "status must be 'active' or 'closed'")
    if patch:
        await get_db().grants.update_one({"_id": g["_id"]}, {"$set": patch})
    return clean_doc(await get_owned_grant(grant_id, user["_id"]))


@app.delete("/api/grants/{grant_id}", status_code=204)
async def delete_grant(grant_id: str, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    db = get_db()
    await db.expenses.delete_many({"grant_id": g["_id"]})
    await db.outcomes.delete_many({"grant_id": g["_id"]})
    await db.grants.delete_one({"_id": g["_id"]})
    return None


# ----------------------------------------------------------------- expenses ---

@app.get("/api/grants/{grant_id}/expenses")
async def list_expenses(grant_id: str, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    out = []
    async for e in get_db().expenses.find({"grant_id": g["_id"]}).sort("date", -1):
        out.append(clean_doc(e))
    return out


@app.post("/api/grants/{grant_id}/expenses", status_code=201)
async def add_expense(grant_id: str, body: ExpenseIn, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    e = {
        "_id": new_id(),
        "grant_id": g["_id"],
        "user_id": user["_id"],
        "category": body.category,
        "amount": body.amount,
        "date": body.date,
        "vendor": body.vendor,
        "description": body.description,
        "receipt_file": None,
        "created_at": now_iso(),
    }
    await get_db().expenses.insert_one(e)
    return clean_doc(e)


@app.patch("/api/expenses/{expense_id}")
async def patch_expense(expense_id: str, body: ExpensePatch, user: dict = Depends(current_user)):
    e = await get_db().expenses.find_one({"_id": expense_id, "user_id": user["_id"]})
    if not e:
        raise HTTPException(404, "Expense not found")
    patch = {k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None}
    if patch:
        await get_db().expenses.update_one({"_id": expense_id}, {"$set": patch})
    return clean_doc(await get_db().expenses.find_one({"_id": expense_id}))


@app.delete("/api/expenses/{expense_id}", status_code=204)
async def delete_expense(expense_id: str, user: dict = Depends(current_user)):
    await get_db().expenses.delete_one({"_id": expense_id, "user_id": user["_id"]})
    return None


@app.post("/api/expenses/{expense_id}/receipt")
async def attach_receipt(expense_id: str, file: UploadFile, user: dict = Depends(current_user)):
    e = await get_db().expenses.find_one({"_id": expense_id, "user_id": user["_id"]})
    if not e:
        raise HTTPException(404, "Expense not found")
    fname = slug_filename(file.filename or "receipt.jpg")
    dest = os.path.join(settings.upload_dir, fname)
    with open(dest, "wb") as f:
        f.write(await file.read())
    await get_db().expenses.update_one({"_id": expense_id}, {"$set": {"receipt_file": fname}})
    return {"receipt_file": fname, "url": f"/uploads/{fname}"}


# ----------------------------------------------------------------- outcomes ---

@app.get("/api/grants/{grant_id}/outcomes")
async def list_outcomes(grant_id: str, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    out = []
    async for o in get_db().outcomes.find({"grant_id": g["_id"]}).sort("date", -1):
        out.append(clean_doc(o))
    return out


@app.post("/api/grants/{grant_id}/outcomes", status_code=201)
async def add_outcome(grant_id: str, body: OutcomeIn, user: dict = Depends(current_user)):
    g = await get_owned_grant(grant_id, user["_id"])
    o = {
        "_id": new_id(),
        "grant_id": g["_id"],
        "user_id": user["_id"],
        "title": body.title.strip(),
        "detail": body.detail,
        "metric_value": body.metric_value,
        "metric_unit": body.metric_unit,
        "date": body.date or now_iso()[:10],
        "created_at": now_iso(),
    }
    await get_db().outcomes.insert_one(o)
    return clean_doc(o)


@app.patch("/api/outcomes/{outcome_id}")
async def patch_outcome(outcome_id: str, body: OutcomePatch, user: dict = Depends(current_user)):
    o = await get_db().outcomes.find_one({"_id": outcome_id, "user_id": user["_id"]})
    if not o:
        raise HTTPException(404, "Outcome not found")
    patch = {k: v for k, v in body.model_dump(exclude_unset=True).items() if v is not None}
    if patch:
        await get_db().outcomes.update_one({"_id": outcome_id}, {"$set": patch})
    return clean_doc(await get_db().outcomes.find_one({"_id": outcome_id}))


@app.delete("/api/outcomes/{outcome_id}", status_code=204)
async def delete_outcome(outcome_id: str, user: dict = Depends(current_user)):
    await get_db().outcomes.delete_one({"_id": outcome_id, "user_id": user["_id"]})
    return None


# ------------------------------------------------------------------ reports ---

import jwt as _jwt
from fastapi import Query
from fastapi.security import HTTPAuthorizationCredentials


async def _report_user(
    token: Optional[str], creds: Optional[HTTPAuthorizationCredentials]
) -> dict:
    """Report links are opened in a plain browser window, which cannot attach
    an Authorization header — so report endpoints also accept ?token=<jwt>."""
    if creds is not None:
        try:
            payload = _jwt.decode(creds.credentials, settings.jwt_secret, algorithms=["HS256"])
            u = await get_db().users.find_one({"_id": payload["sub"]})
            if u:
                return u
        except _jwt.PyJWTError:
            pass
    if token:
        try:
            payload = _jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
            u = await get_db().users.find_one({"_id": payload["sub"]})
            if u:
                return u
        except _jwt.PyJWTError:
            pass
    raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not signed in")


async def _report_bundle(grant_id: str, user: dict) -> dict:
    g = await get_owned_grant(grant_id, user["_id"])
    db = get_db()
    expenses, outcomes = [], []
    async for e in db.expenses.find({"grant_id": g["_id"]}).sort("date", 1):
        expenses.append(clean_doc(e))
    async for o in db.outcomes.find({"grant_id": g["_id"]}).sort("date", 1):
        outcomes.append(clean_doc(o))
    return {
        "grant": clean_doc(g),
        "summary": await grant_summary(g),
        "expenses": expenses,
        "outcomes": outcomes,
        "user": clean_doc(user),
    }


@app.get("/api/grants/{grant_id}/report")
async def closeout_report(
    grant_id: str,
    token: Optional[str] = Query(default=None),
    creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
):
    """Printable closeout report (HTML). Browser-safe via ?token=<jwt>."""
    u = await _report_user(token, creds)
    bundle = await _report_bundle(grant_id, u)
    return HTMLResponse(reports_gen.render_closeout(bundle))


@app.get("/api/grants/{grant_id}/report.json")
async def closeout_report_json(grant_id: str, user: dict = Depends(current_user)):
    return await _report_bundle(grant_id, user)


@app.post("/api/grants/{grant_id}/ai-summary")
async def ai_summary(grant_id: str, user: dict = Depends(current_user)):
    bundle = await _report_bundle(grant_id, user)
    text = await ai.write_summary(bundle)
    return {"summary": text}


@app.post("/api/grants/{grant_id}/share")
async def share_report(grant_id: str, body: ShareReportIn, user: dict = Depends(current_user)):
    if not EMAIL_RE.match(body.to):
        raise HTTPException(422, "Enter a valid recipient email")
    bundle = await _report_bundle(grant_id, user)
    link = f"{settings.public_base_url}/api/grants/{grant_id}/report"
    ok = emailer.send_report_link(
        to=body.to,
        grant_name=bundle["grant"]["name"],
        org=user.get("org_name") or user["name"],
        sender_name=user["name"],
        report_link=link,
    )
    if not ok:
        raise HTTPException(
            503,
            "Email is not configured on this server. Set SMTP_* variables, "
            "or copy the report link manually.",
        )
    return {"sent": True, "to": body.to}


# -------------------------------------------------------------------- misc ---

@app.get("/api/health")
async def health():
    return {"ok": True, "service": "grantclose"}
