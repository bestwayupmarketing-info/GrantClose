"""Smoke tests: app imports, OpenAPI schema, auth flow with a fake DB layer."""
import os
import sys

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import core  # noqa: E402
import server  # noqa: E402


class FakeCursor:
    def __init__(self, docs):
        self.docs = list(docs)

    def sort(self, *a, **k):
        return self

    async def __aiter__(self):
        for d in self.docs:
            yield d


class FakeCollection:
    def __init__(self, docs=None):
        self.docs = docs if docs is not None else []

    async def find_one(self, q):
        for d in self.docs:
            if all(d.get(k) == v for k, v in q.items()):
                return d
        return None

    async def insert_one(self, d):
        self.docs.append(d)

    def find(self, q):
        return FakeCursor([d for d in self.docs if all(d.get(k) == v for k, v in q.items())])

    async def update_one(self, q, op):
        for d in self.docs:
            if all(d.get(k) == v for k, v in q.items()):
                d.update(op.get("$set", {}))

    async def delete_many(self, q):
        self.docs = [d for d in self.docs if not all(d.get(k) == v for k, v in q.items())]

    async def delete_one(self, q):
        await self.delete_many(q)

    async def create_index(self, *a, **k):
        return None


class FakeDB:
    def __init__(self):
        self.users = FakeCollection()
        self.grants = FakeCollection()
        self.expenses = FakeCollection()
        self.outcomes = FakeCollection()


@pytest.fixture()
def client():
    fake = FakeDB()
    server.get_db = lambda: fake  # type: ignore[assignment]
    core.get_db = lambda: fake  # type: ignore[assignment]
    with TestClient(server.app) as c:
        yield c, fake


def test_openapi(client):
    c, _ = client
    r = c.get("/openapi.json")
    assert r.status_code == 200
    assert "/api/grants" in r.json()["paths"]


def test_register_login_and_grant_flow(client):
    c, fake = client
    r = c.post("/api/auth/register", json={
        "email": "team@example.org", "password": "password123",
        "name": "Sam", "org_name": "River Fund",
    })
    assert r.status_code == 200, r.text
    token = r.json()["token"]

    auth = {"Authorization": f"Bearer {token}"}
    r = c.post("/api/grants", headers=auth, json={
        "name": "Summer Literacy", "funder": "City Arts Council",
        "amount_total": 5000,
        "categories": [{"name": "Books", "budgeted": 3000}, {"name": "Venue", "budgeted": 2000}],
    })
    assert r.status_code == 201, r.text
    gid = r.json()["id"]

    r = c.post(f"/api/grants/{gid}/expenses", headers=auth, json={
        "category": "Books", "amount": 125.5, "date": "2026-08-01", "vendor": "Bookshop",
    })
    assert r.status_code == 201

    r = c.post(f"/api/grants/{gid}/outcomes", headers=auth, json={
        "title": "200 books distributed", "metric_value": 200, "metric_unit": "books",
    })
    assert r.status_code == 201

    r = c.get(f"/api/grants/{gid}", headers=auth)
    body = r.json()
    assert body["summary"]["total_spent"] == 125.5
    assert body["summary"]["categories"][0]["remaining"] == 2874.5

    r = c.get(f"/api/grants/{gid}/report", headers=auth)
    assert r.status_code == 200
    assert "Summer Literacy" in r.text and "Budget vs. actual" in r.text

    r = c.post(f"/api/grants/{gid}/ai-summary", headers=auth)
    assert r.status_code == 200 and len(r.json()["summary"]) > 50

    r = c.post("/api/auth/login", json={"email": "team@example.org", "password": "wrong"})
    assert r.status_code == 401


def test_auth_required(client):
    c, _ = client
    assert c.get("/api/grants").status_code in (401, 403)
