import React from 'react';
import { Text } from 'react-native';
import { Tabs, Redirect } from 'expo-router';
import { useAuth } from '@/src/auth';
import { colors } from '@/constants/theme';

function Glyph({ char, focused }: { char: string; focused: boolean }) {
  return (
    <Text style={{ fontSize: 18, color: focused ? colors.primary : colors.sub }}>{char}</Text>
  );
}

export default function TabsLayout() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Redirect href="/login" />;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.sub,
        headerTitleStyle: { color: colors.ink },
        tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.line },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ focused }) => <Glyph char="⌂" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="grants"
        options={{
          title: 'Grants',
          tabBarIcon: ({ focused }) => <Glyph char="▤" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="reports"
        options={{
          title: 'Reports',
          tabBarIcon: ({ focused }) => <Glyph char="✓" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarIcon: ({ focused }) => <Glyph char="⚙" focused={focused} />,
        }}
      />
    </Tabs>
  );
}
