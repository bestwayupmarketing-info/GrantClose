import React, { useCallback, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Screen, Title, Card, Button, Chip, EmptyState, ProgressBar } from '@/src/components/ui';
import { api } from '@/src/api';
import { money, pct } from '@/src/format';
import type { Grant } from '@/src/types';
import { colors } from '@/constants/theme';

export default function Grants() {
  const router = useRouter();
  const [grants, setGrants] = useState<Grant[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'closed'>('all');

  useFocusEffect(
    useCallback(() => {
      api.get<Grant[]>('/api/grants').then(setGrants).catch(() => {});
    }, [])
  );

  const shown = grants.filter((g) => filter === 'all' || g.status === filter);

  return (
    <Screen>
      <Title sub="Every grant, its budget, and how much is left.">Grants</Title>
      <View style={s.filters}>
        {(['all', 'active', 'closed'] as const).map((f) => (
          <Button key={f} label={f[0].toUpperCase() + f.slice(1)} small variant={filter === f ? 'primary' : 'ghost'} onPress={() => setFilter(f)} />
        ))}
        <View style={{ flex: 1 }} />
        <Button label="+ New" small onPress={() => router.push('/grant/new')} />
      </View>

      {shown.length === 0 ? (
        <EmptyState title="Nothing here yet" hint="Create a grant to start organizing receipts, spending, and outcomes." />
      ) : (
        shown.map((g) => {
          const sm = g.summary;
          const budget = sm?.total_budgeted ?? g.amount_total;
          const spent = sm?.total_spent ?? 0;
          return (
            <Pressable key={g.id} onPress={() => router.push(`/grant/${g.id}`)}>
              <Card>
                <View style={s.rowBetween}>
                  <Text style={s.name}>{g.name}</Text>
                  <Chip label={g.status} tone={g.status === 'closed' ? 'warn' : 'ok'} />
                </View>
                {!!g.funder && <Text style={s.funder}>{g.funder}</Text>}
                <ProgressBar spent={spent} budget={budget} />
                <Text style={s.meta}>
                  {money(spent)} of {money(budget)} · {pct(spent, budget)}% used
                  {sm && sm.uncategorized_spent > 0 ? ` · ${money(sm.uncategorized_spent)} uncategorized` : ''}
                </Text>
              </Card>
            </Pressable>
          );
        })
      )}
    </Screen>
  );
}

const s = StyleSheet.create({
  filters: { flexDirection: 'row', gap: 8, alignItems: 'center', flexWrap: 'wrap' },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  name: { fontSize: 16, fontWeight: '700', color: colors.ink, flex: 1, marginRight: 8 },
  funder: { fontSize: 13, color: colors.sub },
  meta: { fontSize: 12.5, color: colors.sub },
});
