import React, { useCallback, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Link, useFocusEffect, useRouter } from 'expo-router';
import { Screen, Title, Card, Button, Chip, EmptyState, ProgressBar } from '@/src/components/ui';
import { api } from '@/src/api';
import { useAuth } from '@/src/auth';
import { money, pct, shortDate } from '@/src/format';
import type { Grant } from '@/src/types';
import { colors, spacing } from '@/constants/theme';

export default function Home() {
  const { user } = useAuth();
  const router = useRouter();
  const [grants, setGrants] = useState<Grant[]>([]);

  useFocusEffect(
    useCallback(() => {
      api.get<Grant[]>('/api/grants').then(setGrants).catch(() => {});
    }, [])
  );

  const active = grants.filter((g) => g.status === 'active');
  const totalAward = grants.reduce((a, g) => a + (g.summary?.total_budgeted ?? g.amount_total), 0);
  const totalSpent = grants.reduce((a, g) => a + (g.summary?.total_spent ?? 0), 0);

  return (
    <Screen>
      <Title sub={user?.org_name ? `${user.org_name}` : undefined}>
        Hello, {user?.name?.split(' ')[0]}
      </Title>

      <Card style={s.statCard}>
        <Text style={s.statLabel}>Across {grants.length} grant{grants.length === 1 ? '' : 's'}</Text>
        <Text style={s.statBig}>
          {money(totalSpent)} <Text style={s.statOf}>of {money(totalAward)}</Text>
        </Text>
        <ProgressBar spent={totalSpent} budget={totalAward} />
        <Text style={s.statPct}>{pct(totalSpent, totalAward)}% spent</Text>
      </Card>

      <View style={s.quickRow}>
        <Link href="/grant/new" asChild>
          <Button label="+ New grant" small onPress={() => {}} />
        </Link>
        {active[0] && (
          <Button
            label="+ Expense"
            small
            variant="ghost"
            onPress={() => router.push(`/expense/new?grantId=${active[0].id}`)}
          />
        )}
        <Link href="/documents" asChild>
          <Button label="Receipts" small variant="ghost" onPress={() => {}} />
        </Link>
      </View>

      <Text style={s.sectionTitle}>Active grants</Text>
      {active.length === 0 ? (
        <EmptyState title="No active grants" hint="Create your first grant to start tracking spending against its budget." />
      ) : (
        active.map((g) => {
          const s = g.summary;
          const p = pct(s?.total_spent ?? 0, s?.total_budgeted ?? g.amount_total);
          return (
            <Pressable key={g.id} onPress={() => router.push(`/grant/${g.id}`)}>
              <Card>
                <View style={s2.rowBetween}>
                  <Text style={s2.grantName}>{g.name}</Text>
                  <Chip label={g.status} tone={g.status === 'closed' ? 'warn' : 'ok'} />
                </View>
                {!!g.funder && <Text style={s2.funder}>{g.funder}</Text>}
                <ProgressBar spent={s?.total_spent ?? 0} budget={s?.total_budgeted ?? g.amount_total} />
                <View style={s2.rowBetween}>
                  <Text style={s2.meta}>
                    {money(s?.total_spent ?? 0)} spent · {p}%
                  </Text>
                  <Text style={s2.meta}>ends {shortDate(g.end_date)}</Text>
                </View>
              </Card>
            </Pressable>
          );
        })
      )}
    </Screen>
  );
}

const s = StyleSheet.create({
  statCard: { gap: spacing(2) },
  statLabel: { fontSize: 12, color: colors.sub, textTransform: 'uppercase', letterSpacing: 0.5, fontWeight: '700' },
  statBig: { fontSize: 28, fontWeight: '800', color: colors.ink },
  statOf: { fontSize: 15, fontWeight: '500', color: colors.sub },
  statPct: { fontSize: 12.5, color: colors.sub },
  quickRow: { flexDirection: 'row', gap: spacing(2), flexWrap: 'wrap' },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: colors.ink, marginTop: spacing(2) },
});

const s2 = StyleSheet.create({
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  grantName: { fontSize: 16, fontWeight: '700', color: colors.ink, flex: 1, marginRight: 8 },
  funder: { fontSize: 13, color: colors.sub },
  meta: { fontSize: 12.5, color: colors.sub },
});
