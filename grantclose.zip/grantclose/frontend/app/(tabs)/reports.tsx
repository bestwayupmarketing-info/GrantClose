import React, { useCallback, useState } from 'react';
import { Pressable, StyleSheet, Text, View, Alert } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Screen, Title, Card, Button, EmptyState, Chip, ErrorText } from '@/src/components/ui';
import { api } from '@/src/api';
import { getToken, apiUrl } from '@/src/api';
import { useAuth } from '@/src/auth';
import { money, shortDate } from '@/src/format';
import type { Grant } from '@/src/types';
import { colors } from '@/constants/theme';

export default function Reports() {
  const { user } = useAuth();
  const router = useRouter();
  const [grants, setGrants] = useState<Grant[]>([]);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      api.get<Grant[]>('/api/grants').then(setGrants).catch(() => {});
    }, [])
  );

  async function share(g: Grant) {
    setError(null);
    const to = user?.email ?? '';
    try {
      await api.post(`/api/grants/${g.id}/share`, { to });
      Alert.alert('Report sent', `The closeout link was emailed to ${to}.`);
    } catch (e: any) {
      setError(e.message);
    }
  }

  return (
    <Screen>
      <Title sub="Generate printable closeout reports, ready for your funder.">Reports</Title>
      <ErrorText message={error} />
      {grants.length === 0 ? (
        <EmptyState title="No grants to report on" hint="Create a grant first — its closeout report will appear here." />
      ) : (
        grants.map((g) => {
          const s = g.summary;
          return (
            <Card key={g.id}>
              <View style={s2.rowBetween}>
                <Text style={s2.name}>{g.name}</Text>
                <Chip label={g.status} tone={g.status === 'closed' ? 'warn' : 'ok'} />
              </View>
              <Text style={s2.meta}>
                {money(s?.total_spent ?? 0)} spent of {money(s?.total_budgeted ?? g.amount_total)}
                {g.end_date ? ` · ended ${shortDate(g.end_date)}` : ''}
              </Text>
              <View style={s2.actions}>
                <Button label="View report" small onPress={() => router.push(`/report/${g.id}`)} />
                <Button label="Share" small variant="ghost" onPress={() => share(g)} />
              </View>
            </Card>
          );
        })
      )}
    </Screen>
  );
}

const s2 = StyleSheet.create({
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  name: { fontSize: 16, fontWeight: '700', color: colors.ink, flex: 1, marginRight: 8 },
  meta: { fontSize: 13, color: colors.sub },
  actions: { flexDirection: 'row', gap: 8, marginTop: 4 },
});
