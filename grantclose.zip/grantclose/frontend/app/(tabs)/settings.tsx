import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen, Title, Card, Button } from '@/src/components/ui';
import { useAuth } from '@/src/auth';
import { colors, spacing } from '@/constants/theme';

const LINKS: [string, string][] = [
  ['Account profile', '/account'],
  ['Documents & receipts', '/documents'],
  ['Search everything', '/search'],
  ['Notifications', '/notifications'],
  ['Team', '/team'],
  ['Billing (self-hosting costs)', '/billing'],
  ['Help & FAQ', '/help'],
  ['Privacy & terms', '/legal'],
];

export default function Settings() {
  const { user, signOut } = useAuth();
  const router = useRouter();

  return (
    <Screen>
      <Title sub={user?.email}>Settings</Title>
      <Card>
        <Text style={s.name}>{user?.name}</Text>
        {!!user?.org_name && <Text style={s.org}>{user.org_name}</Text>}
        <Text style={s.email}>{user?.email}</Text>
      </Card>
      <Card style={{ paddingVertical: spacing(1) }}>
        {LINKS.map(([label, href], i) => (
          <Pressable key={href} onPress={() => router.push(href as any)} style={[s.link, i > 0 && s.linkBorder]}>
            <Text style={s.linkText}>{label}</Text>
            <Text style={s.chev}>›</Text>
          </Pressable>
        ))}
      </Card>
      <Button label="Sign out" variant="danger" onPress={async () => { await signOut(); router.replace('/welcome'); }} />
      <Text style={s.version}>GrantClose 1.0 · self-hosted</Text>
    </Screen>
  );
}

const s = StyleSheet.create({
  name: { fontSize: 18, fontWeight: '800', color: colors.ink },
  org: { fontSize: 14, color: colors.primaryDark, fontWeight: '600' },
  email: { fontSize: 13, color: colors.sub },
  link: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 13 },
  linkBorder: { borderTopWidth: 1, borderTopColor: colors.line },
  linkText: { fontSize: 15, color: colors.ink },
  chev: { fontSize: 20, color: colors.sub },
  version: { textAlign: 'center', fontSize: 12, color: colors.sub, marginTop: spacing(2) },
});
