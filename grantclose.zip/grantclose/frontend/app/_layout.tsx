import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '@/src/auth';
import { colors } from '@/constants/theme';

export default function RootLayout() {
  return (
    <AuthProvider>
      <StatusBar style="dark" />
      <Stack
        screenOptions={{
          headerTintColor: colors.primaryDark,
          headerTitleStyle: { color: colors.ink },
          contentStyle: { backgroundColor: colors.bg },
        }}
      >
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen name="welcome" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="login" options={{ title: 'Sign in' }} />
        <Stack.Screen name="register" options={{ title: 'Create account' }} />
        <Stack.Screen name="forgot" options={{ title: 'Reset password' }} />
        <Stack.Screen name="onboarding" options={{ title: 'Welcome to GrantClose', headerShown: false }} />
        <Stack.Screen name="grant/new" options={{ title: 'New grant' }} />
        <Stack.Screen name="grant/[id]" options={{ title: 'Grant' }} />
        <Stack.Screen name="expense/new" options={{ title: 'Add expense' }} />
        <Stack.Screen name="outcome/new" options={{ title: 'Add outcome' }} />
        <Stack.Screen name="report/[id]" options={{ title: 'Closeout report' }} />
        <Stack.Screen name="documents" options={{ title: 'Documents & receipts' }} />
        <Stack.Screen name="search" options={{ title: 'Search' }} />
        <Stack.Screen name="account" options={{ title: 'Account' }} />
        <Stack.Screen name="team" options={{ title: 'Team' }} />
        <Stack.Screen name="billing" options={{ title: 'Billing' }} />
        <Stack.Screen name="notifications" options={{ title: 'Notifications' }} />
        <Stack.Screen name="help" options={{ title: 'Help' }} />
        <Stack.Screen name="legal" options={{ title: 'Privacy & terms' }} />
      </Stack>
    </AuthProvider>
  );
}
