import React, { useState } from 'react';
import { StyleSheet, Text } from 'react-native';
import { Screen, Title, Card, Field, Button, ErrorText } from '@/src/components/ui';
import { useAuth } from '@/src/auth';
import { api } from '@/src/api';
import { colors } from '@/constants/theme';

export default function Account() {
  const { user, refresh } = useAuth();
  const [name, setName] = useState(user?.name ?? '');
  const [org, setOrg] = useState(user?.org_name ?? '');
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function save() {
    setMsg(null);
    setError(null);
    setBusy(true);
    try {
      await api.patch('/api/auth/me', {});
      setMsg('Profile is managed at sign-up in this build. Changes here are not saved.');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <Title sub={user?.email}>Account</Title>
      <Card>
        <Field label="Name" value={name} onChangeText={setName} />
        <Field label="Organization" value={org} onChangeText={setOrg} />
        <Field label="Email" value={user?.email ?? ''} editable={false} />
        <ErrorText message={error} />
        {msg && <Text style={{ color: colors.warn, fontSize: 13, fontWeight: '600' }}>{msg}</Text>}
        <Button label="Save" onPress={save} loading={busy} />
      </Card>
      <Text style={s.note}>
        Running GrantClose yourself? All data lives in your own database and storage — nothing
        leaves your server except the emails you choose to send.
      </Text>
    </Screen>
  );
}

const s = StyleSheet.create({
  note: { fontSize: 12.5, color: colors.sub, lineHeight: 19 },
});
