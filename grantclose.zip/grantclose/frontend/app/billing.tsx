import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { Screen, Title, Card, Row } from '@/src/components/ui';
import { colors } from '@/constants/theme';

export default function Billing() {
  return (
    <Screen>
      <Title sub="You host it — so billing is whatever your host charges you.">Hosting costs</Title>
      <Card>
        <Text style={s.title}>Typical monthly cost: $0–7</Text>
        <Row label="MongoDB Atlas M0 (shared)" value="Free" />
        <Row label="Backend (Render/Fly free tier)" value="$0–5" />
        <Row label="Static web export (Cloudflare/Netlify)" value="Free" />
        <Row label="Your time" value="~0 h" strong />
      </Card>
      <Card>
        <Text style={s.title}>Why so cheap?</Text>
        <Text style={s.body}>
          GrantClose is a lightweight FastAPI service plus a static frontend. There is no
          per-seat pricing and no platform markup — the code is yours. See DEPLOY.md in the
          project for step-by-step hosting instructions.
        </Text>
      </Card>
    </Screen>
  );
}

const s = StyleSheet.create({
  title: { fontSize: 15, fontWeight: '700', color: colors.ink },
  body: { fontSize: 13.5, color: colors.sub, lineHeight: 20 },
});
