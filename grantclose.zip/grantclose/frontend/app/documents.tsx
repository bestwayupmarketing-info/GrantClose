import React, { useCallback, useState } from 'react';
import { Image, Platform, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen, Title, Card, EmptyState } from '@/src/components/ui';
import { api, apiUrl } from '@/src/api';
import { money, shortDate } from '@/src/format';
import type { Expense, Grant } from '@/src/types';
import { colors } from '@/constants/theme';

export default function Documents() {
  const [grants, setGrants] = useState<Grant[]>([]);
  const [docs, setDocs] = useState<(Expense & { grantName: string })[]>([]);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        try {
          const gs = await api.get<Grant[]>('/api/grants');
          setGrants(gs);
          const all: (Expense & { grantName: string })[] = [];
          for (const g of gs) {
            const exps = await api.get<Expense[]>(`/api/grants/${g.id}/expenses`);
            for (const e of exps) {
              if (e.receipt_file) all.push({ ...e, grantName: g.name });
            }
          }
          setDocs(all.sort((a, b) => (a.date < b.date ? 1 : -1)));
        } catch {
          /* ignore */
        }
      })();
    }, [])
  );

  return (
    <Screen>
      <Title sub="Every receipt photo you've attached, in one place.">Documents & receipts</Title>
      {docs.length === 0 ? (
        <EmptyState title="No receipts yet" hint="Attach receipt photos when adding expenses and they'll show up here." />
      ) : (
        docs.map((d) => (
          <Card key={d.id} style={{ paddingVertical: 12 }}>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              {Platform.OS === 'web' ? (
                // eslint-disable-next-line @typescript-eslint/no-unused-expressions
                <img src={apiUrl(`/uploads/${d.receipt_file}`)} alt="receipt" style={s.img as any} />
              ) : (
                <Image source={{ uri: apiUrl(`/uploads/${d.receipt_file!}`) }} style={s.thumb} />
              )}
              <View style={{ flex: 1 }}>
                <Text style={s.name}>{d.vendor || 'Receipt'}</Text>
                <Text style={s.meta}>
                  {d.grantName} · {shortDate(d.date)} · {money(d.amount)}
                </Text>
              </View>
            </View>
          </Card>
        ))
      )}
    </Screen>
  );
}

const s = StyleSheet.create({
  thumb: { width: 64, height: 64, borderRadius: 10, backgroundColor: colors.line },
  img: { width: 64, height: 64, borderRadius: 10, objectFit: 'cover' },
  name: { fontSize: 15, fontWeight: '700', color: colors.ink },
  meta: { fontSize: 12.5, color: colors.sub, marginTop: 2 },
});
