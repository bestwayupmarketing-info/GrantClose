import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Image, Platform, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { Screen, Title, Card, Field, Button, ErrorText } from '@/src/components/ui';
import { api, apiUrl } from '@/src/api';
import { colors, spacing } from '@/constants/theme';
import type { Grant } from '@/src/types';

export default function NewExpense() {
  const { grantId } = useLocalSearchParams<{ grantId: string }>();
  const router = useRouter();
  const [grants, setGrants] = useState<Grant[]>([]);
  const [grant, setGrant] = useState<Grant | null>(null);
  const [category, setCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [vendor, setVendor] = useState('');
  const [description, setDescription] = useState('');
  const [receipt, setReceipt] = useState<{ uri: string; name: string; type: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const webInputRef = useRef<any>(null);
  const webFileRef = useRef<File | null>(null);

  useFocusEffect(
    useCallback(() => {
      api.get<Grant[]>('/api/grants').then((gs) => {
        setGrants(gs.filter((g) => g.status === 'active'));
        const pre = gs.find((g) => g.id === grantId) ?? gs.find((g) => g.status === 'active');
        if (pre) setGrant(pre);
      }).catch(() => {});
    }, [grantId])
  );

  async function pickReceipt() {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.8,
    });
    const asset = res.assets?.[0];
    if (res.canceled || !asset) return;
    setReceipt({
      uri: asset.uri,
      name: asset.fileName ?? 'receipt.jpg',
      type: asset.mimeType ?? 'image/jpeg',
    });
  }

  function onWebFile(e: any) {
    const f: File = e.target.files?.[0];
    if (!f) return;
    webFileRef.current = f;
    setReceipt({ uri: URL.createObjectURL(f), name: f.name, type: f.type || 'image/jpeg' });
  }

  async function submit() {
    setError(null);
    const amt = parseFloat(amount);
    if (!grant) return setError('Pick a grant first.');
    if (!category) return setError('Pick a budget category.');
    if (!amt || amt <= 0) return setError('Enter the amount spent.');
    if (!date) return setError('Enter the date.');
    setBusy(true);
    try {
      const e = await api.post<{ id: string }>(`/api/grants/${grant.id}/expenses`, {
        category,
        amount: amt,
        date,
        vendor,
        description,
      });
      if (receipt) {
        const form = new FormData();
        if (Platform.OS === 'web' && webFileRef.current) {
          form.append('file', webFileRef.current, receipt.name);
        } else {
          // React Native FormData file object
          form.append('file', { uri: receipt.uri, name: receipt.name, type: receipt.type } as any);
        }
        try {
          await api.upload(`/api/expenses/${e.id}/receipt`, form);
        } catch {
          setError('Expense saved, but the receipt upload failed — try attaching it again.');
          setBusy(false);
          return;
        }
      }
      router.replace(`/grant/${grant.id}`);
    } catch (e: any) {
      setError(e.message ?? 'Could not save expense');
    } finally {
      setBusy(false);
    }
  }

  const cats = grant?.categories ?? [];

  return (
    <Screen>
      <Title sub="Snap the receipt now so closeout is painless later.">Add expense</Title>

      <Card>
        <Text style={s.label}>Grant</Text>
        <View style={s.chipsWrap}>
          {grants.map((g) => (
            <Button
              key={g.id}
              label={g.name}
              small
              variant={grant?.id === g.id ? 'primary' : 'ghost'}
              onPress={() => { setGrant(g); setCategory(''); }}
            />
          ))}
          {grants.length === 0 && <Text style={s.hint}>No active grants — create one first.</Text>}
        </View>

        {cats.length > 0 && (
          <>
            <Text style={s.label}>Category</Text>
            <View style={s.chipsWrap}>
              {cats.map((c) => (
                <Button
                  key={c.name}
                  label={c.name}
                  small
                  variant={category === c.name ? 'primary' : 'ghost'}
                  onPress={() => setCategory(c.name)}
                />
              ))}
            </View>
          </>
        )}
        {cats.length === 0 && grant && (
          <Field label="Category" value={category} onChangeText={setCategory} placeholder="e.g. Supplies" />
        )}

        <Field label="Amount ($)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="125.50" />
        <Field label="Date" value={date} onChangeText={setDate} placeholder="2026-08-01" />
        <Field label="Vendor (optional)" value={vendor} onChangeText={setVendor} placeholder="Bookshop" />
        <Field label="Description (optional)" value={description} onChangeText={setDescription} placeholder="50 children's books" />
      </Card>

      <Card>
        <Text style={s.label}>Receipt photo</Text>
        {receipt && <Image source={{ uri: receipt.uri }} style={s.preview} />}
        <View style={s.receiptRow}>
          {Platform.OS === 'web' ? (
            <>
              <input ref={webInputRef} type="file" accept="image/*" onChange={onWebFile} style={s.webInput} />
              <Button label={receipt ? 'Change photo' : 'Choose photo'} small variant="ghost" onPress={() => webInputRef.current?.click()} />
            </>
          ) : (
            <Button label={receipt ? 'Change photo' : 'Take / choose photo'} small variant="ghost" onPress={pickReceipt} />
          )}
          {receipt && (
            <Button label="Remove" small variant="danger" onPress={() => { setReceipt(null); webFileRef.current = null; }} />
          )}
        </View>
      </Card>

      <ErrorText message={error} />
      <Button label="Save expense" onPress={submit} loading={busy} disabled={!grant} />
    </Screen>
  );
}

const s = StyleSheet.create({
  label: { fontSize: 13, fontWeight: '600', color: colors.ink, marginTop: 4 },
  chipsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  hint: { fontSize: 13, color: colors.sub },
  preview: { width: '100%', height: 180, borderRadius: 12, resizeMode: 'cover' as const, backgroundColor: colors.line },
  receiptRow: { flexDirection: 'row', gap: 8 },
  webInput: { display: 'none' },
});
