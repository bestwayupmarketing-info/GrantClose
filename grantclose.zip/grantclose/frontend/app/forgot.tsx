import React, { useState } from 'react';
import { Text } from 'react-native';
import { Screen, Title, Card, Field, Button } from '@/src/components/ui';
import { colors } from '@/constants/theme';

export default function Forgot() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  return (
    <Screen>
      <Title sub="Password reset is handled by your server's administrator in this self-hosted build.">
        Reset password
      </Title>
      <Card>
        {sent ? (
          <Text style={{ color: colors.ok, fontWeight: '600' }}>
            If an account exists for {email}, your administrator can reset it from the server.
          </Text>
        ) : (
          <>
            <Field label="Account email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
            <Button label="Request reset" onPress={() => setSent(true)} />
            <Text style={{ fontSize: 12.5, color: colors.sub }}>
              Tip: admins can delete and recreate a user directly in the database if email is not
              configured.
            </Text>
          </>
        )}
      </Card>
    </Screen>
  );
}
