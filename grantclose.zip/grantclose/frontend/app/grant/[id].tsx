import React, { useCallback, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Screen, Title, Card, Button, Chip, EmptyState, ProgressBar, Row, ErrorText } from '@/src/components/ui';
import { api, apiUrl } from '@/src/api';
import { money, pct, shortDate } from '@/src/format';
import type { Expense, Grant, Outcome } from '@/src/types';
import { colors, spacing } from '@/constants/theme';

export default function GrantDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const [grant, setGrant] = useState<Grant | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [outcomes, setOutcomes] = useState<Outcome[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    if (!id) return;
    api.get<Grant>(`/api/grants/${id}`).then(setGrant).catch((e) => setError(e.message));
    api.get<Expense[]>(`/api/grants/${id}/expenses`).then(setExpenses).catch(() => {});
    api.get<Outcome[]>(`/api/grants/${id}/outcomes`).then(setOutcomes).catch(() => {});
  }, [id]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function closeGrant() {
    if (!grant) return;
    await api.patch(`/api/grants/${grant.id}`, { status: grant.status === 'closed' ? 'active' : 'closed' });
    load();
  }

  async function deleteExpense(e: Expense) {
    await api.del(`/api/expenses/${e.id}`);
    load();
  }

  if (!grant) {
    return (
      <Screen>
        <ErrorText message={error} />
        {!error && <Text style={{ color: colors.sub }}>Loading…</Text>}
      </Screen>
    );
  }

  const s = grant.summary;
  const budget = s?.total_budgeted ?? grant.amount_total;
  const spent = s?.total_spent ?? 0;

  return (
    <Screen>
      <Stack.Screen options={{ title: grant.name }} />
      <View style={st.headRow}>
        <View style={{ flex: 1 }}>
          <Title sub={grant.funder ? `Funder: ${grant.funder}` : undefined}>{grant.name}</Title>
        </View>
        <Chip label={grant.status} tone={grant.status === 'closed' ? 'warn' : 'ok'} />
      </View>

      <Card>
        <Row label="Award" value={money(budget)} />
        <Row label="Spent" value={money(spent)} strong />
        <Row label="Remaining" value={money(budget - spent)} />
        <Row label="Period" value={`${shortDate(grant.start_date)} → ${shortDate(grant.end_date)}`} />
        <ProgressBar spent={spent} budget={budget} />
        <Text style={st.pct}>{pct(spent, budget)}% of budget used</Text>
      </Card>

      <View style={st.actionsRow}>
        <Button label="+ Expense" small onPress={() => router.push(`/expense/new?grantId=${grant.id}`)} />
        <Button label="+ Outcome" small variant="ghost" onPress={() => router.push(`/outcome/new?grantId=${grant.id}`)} />
        <Button label="Report" small variant="ghost" onPress={() => router.push(`/report/${grant.id}`)} />
        <Button
          label={grant.status === 'closed' ? 'Reopen' : 'Close'}
          small
          variant="ghost"
          onPress={() =>
            Alert.alert(
              grant.status === 'closed' ? 'Reopen grant?' : 'Close grant?',
              grant.status === 'closed'
                ? 'The grant will be marked active again.'
                : 'Closing marks the grant complete. You can still reopen it later.',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Confirm', onPress: closeGrant },
              ]
            )
          }
        />
      </View>

      <Text style={st.section}>Budget categories</Text>
      {(s?.categories ?? []).map((c) => (
        <Card key={c.name} style={{ paddingVertical: spacing(3) }}>
          <View style={st.rowBetween}>
            <Text style={st.catName}>{c.name}</Text>
            <Text style={st.catNums}>
              {money(c.spent)} / {money(c.budgeted)}
            </Text>
          </View>
          <ProgressBar spent={c.spent ?? 0} budget={c.budgeted} />
          <Text style={[st.meta, (c.remaining ?? 0) < 0 && { color: colors.danger, fontWeight: '700' }]}>
            {(c.remaining ?? 0) < 0
              ? `${money(-(c.remaining ?? 0))} over budget`
              : `${money(c.remaining)} remaining`}
          </Text>
        </Card>
      ))}
      {!!s?.uncategorized_spent && (
        <Card style={{ paddingVertical: spacing(3) }}>
          <Text style={st.catName}>Uncategorized</Text>
          <Text style={[st.meta, { color: colors.warn, fontWeight: '700' }]}>
            {money(s.uncategorized_spent)} — add matching categories so the report balances.
          </Text>
        </Card>
      )}

      <Text style={st.section}>Expenses ({expenses.length})</Text>
      {expenses.length === 0 ? (
        <EmptyState title="No expenses yet" hint="Log spending as it happens, with receipt photos attached." />
      ) : (
        expenses.map((e) => (
          <Card key={e.id} style={{ paddingVertical: spacing(3) }}>
            <View style={st.rowBetween}>
              <Text style={st.catName}>{e.vendor || e.description || 'Expense'}</Text>
              <Text style={st.amount}>{money(e.amount)}</Text>
            </View>
            <Text style={st.meta}>
              {shortDate(e.date)} · {e.category}
              {e.description ? ` · ${e.description}` : ''}
            </Text>
            {e.receipt_file && (
              <Text style={st.receiptLink} onPress={() => router.push('/documents')}>
                📎 Receipt attached
              </Text>
            )}
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 4 }}>
              <Button label="Delete" small variant="danger" onPress={() => Alert.alert('Delete expense?', 'This cannot be undone.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: () => deleteExpense(e) }])} />
            </View>
          </Card>
        ))
      )}

      <Text style={st.section}>Outcomes ({outcomes.length})</Text>
      {outcomes.length === 0 ? (
        <EmptyState title="No outcomes recorded" hint="Capture what the grant achieved — meals served, students reached, events held." />
      ) : (
        outcomes.map((o) => (
          <Card key={o.id} style={{ paddingVertical: spacing(3) }}>
            <View style={st.rowBetween}>
              <Text style={st.catName}>{o.title}</Text>
              {o.metric_value != null && (
                <Chip label={`${o.metric_value} ${o.metric_unit ?? ''}`.trim()} tone="soft" />
              )}
            </View>
            {!!o.detail && <Text style={st.meta}>{o.detail}</Text>}
            <Button
              label="Delete"
              small
              variant="danger"
              onPress={() => Alert.alert('Delete outcome?', '', [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: async () => { await api.del(`/api/outcomes/${o.id}`); load(); } }])}
            />
          </Card>
        ))
      )}

      {!!grant.notes && (
        <>
          <Text style={st.section}>Notes</Text>
          <Card>
            <Text style={st.meta}>{grant.notes}</Text>
          </Card>
        </>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  headRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  pct: { fontSize: 12.5, color: colors.sub },
  actionsRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  section: { fontSize: 16, fontWeight: '700', color: colors.ink, marginTop: spacing(2) },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  catName: { fontSize: 15, fontWeight: '700', color: colors.ink },
  catNums: { fontSize: 13, color: colors.sub },
  meta: { fontSize: 13, color: colors.sub },
  amount: { fontSize: 15, fontWeight: '800', color: colors.ink },
  receiptLink: { fontSize: 13, color: colors.primary, fontWeight: '600', marginTop: 2 },
});
