import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen, Title, Card, Field, Button, ErrorText } from '@/src/components/ui';
import { api } from '@/src/api';
import { colors, spacing } from '@/constants/theme';

type Cat = { name: string; budgeted: string };

export default function NewGrant() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [funder, setFunder] = useState('');
  const [amount, setAmount] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [notes, setNotes] = useState('');
  const [cats, setCats] = useState<Cat[]>([{ name: '', budgeted: '' }]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function setCat(i: number, patch: Partial<Cat>) {
    setCats((c) => c.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  }

  async function submit() {
    setError(null);
    const amountNum = parseFloat(amount);
    if (!name.trim()) return setError('Give the grant a name.');
    if (!amountNum || amountNum <= 0) return setError('Enter the total award amount.');
    const categories = cats
      .filter((c) => c.name.trim())
      .map((c) => ({ name: c.name.trim(), budgeted: parseFloat(c.budgeted) || 0 }));
    const catsTotal = categories.reduce((a, c) => a + c.budgeted, 0);
    if (categories.length && catsTotal > amountNum + 0.01) {
      return setError(`Categories add up to ${catsTotal.toFixed(2)}, more than the award.`);
    }
    setBusy(true);
    try {
      const g = await api.post<{ id: string }>('/api/grants', {
        name: name.trim(),
        funder: funder.trim(),
        amount_total: amountNum,
        start_date: start || null,
        end_date: end || null,
        notes,
        categories,
      });
      router.replace(`/grant/${g.id}`);
    } catch (e: any) {
      setError(e.message ?? 'Could not create grant');
    } finally {
      setBusy(false);
    }
  }

  const catsTotal = cats.reduce((a, c) => a + (parseFloat(c.budgeted) || 0), 0);

  return (
    <Screen>
      <Title sub="The approved budget you set here is what spending is tracked against.">New grant</Title>
      <Card>
        <Field label="Grant name" value={name} onChangeText={setName} placeholder="Summer Literacy Program" />
        <Field label="Funder" value={funder} onChangeText={setFunder} placeholder="City Arts Council" />
        <Field label="Total award ($)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="5000" />
        <View style={s.twoCol}>
          <View style={{ flex: 1 }}>
            <Field label="Start date" value={start} onChangeText={setStart} placeholder="2026-06-01" />
          </View>
          <View style={{ flex: 1 }}>
            <Field label="End date" value={end} onChangeText={setEnd} placeholder="2026-09-30" />
          </View>
        </View>
        <Field label="Notes (optional)" value={notes} onChangeText={setNotes} multiline placeholder="Restrictions, reporting requirements…" />
      </Card>

      <Card>
        <View style={s.catsHeader}>
          <Text style={s.catsTitle}>Budget categories</Text>
          <Text style={s.catsTotal}>{catsTotal.toFixed(2)} / {amount || '0'}</Text>
        </View>
        {cats.map((c, i) => (
          <View key={i} style={s.catRow}>
            <View style={{ flex: 2 }}>
              <Field label={`Category ${i + 1}`} value={c.name} onChangeText={(v) => setCat(i, { name: v })} placeholder="Books" />
            </View>
            <View style={{ flex: 1 }}>
              <Field label="Budget ($)" value={c.budgeted} onChangeText={(v) => setCat(i, { budgeted: v })} keyboardType="decimal-pad" placeholder="3000" />
            </View>
            {cats.length > 1 && (
              <Pressable onPress={() => setCats((x) => x.filter((_, j) => j !== i))} style={s.remove}>
                <Text style={s.removeText}>✕</Text>
              </Pressable>
            )}
          </View>
        ))}
        <Button label="+ Add category" variant="ghost" small onPress={() => setCats((c) => [...c, { name: '', budgeted: '' }])} />
      </Card>

      <ErrorText message={error} />
      <Button label="Create grant" onPress={submit} loading={busy} />
    </Screen>
  );
}

const s = StyleSheet.create({
  twoCol: { flexDirection: 'row', gap: spacing(3) },
  catsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  catsTitle: { fontSize: 15, fontWeight: '700', color: colors.ink },
  catsTotal: { fontSize: 13, color: colors.sub },
  catRow: { flexDirection: 'row', gap: spacing(2), alignItems: 'flex-end' },
  remove: { paddingBottom: 12, paddingHorizontal: 4 },
  removeText: { color: colors.danger, fontSize: 15, fontWeight: '700' },
});
