import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen, Title, Card } from '@/src/components/ui';
import { colors } from '@/constants/theme';

const FAQS: [string, string][] = [
  [
    'How do I build the closeout report?',
    'Open a grant → tap Report. The printable page has a "Print / Save as PDF" button. Save the PDF and email it to your funder, or use Share on the Reports tab.',
  ],
  [
    'Where are my receipt photos stored?',
    'On your own server, in the uploads folder (or the volume you mount in docker). Nothing is sent to third parties.',
  ],
  [
    'What if I go over budget in a category?',
    'The bar turns amber past 85% and red when over. The report still balances — uncategorized and over-budget amounts are shown explicitly.',
  ],
  [
    'Can I use this on my phone?',
    'Yes — it is an Expo app. Run `npm start` in the frontend folder and scan the QR code with Expo Go (iOS/Android).',
  ],
  [
    'Is my data backed up?',
    'Back up your MongoDB database and the uploads folder. With docker-compose, `docker exec` mongodump or snapshot the volumes.',
  ],
];

export default function Help() {
  return (
    <Screen>
      <Title sub="Quick answers for the workflows that matter.">Help & FAQ</Title>
      {FAQS.map(([q, a]) => (
        <Card key={q}>
          <Text style={s.q}>{q}</Text>
          <Text style={s.a}>{a}</Text>
        </Card>
      ))}
    </Screen>
  );
}

const s = StyleSheet.create({
  q: { fontSize: 15, fontWeight: '700', color: colors.ink },
  a: { fontSize: 13.5, color: colors.sub, lineHeight: 20 },
});
