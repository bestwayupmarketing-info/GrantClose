import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { Screen, Title, Card } from '@/src/components/ui';
import { colors } from '@/constants/theme';

export default function Legal() {
  return (
    <Screen>
      <Title sub="Short version: your data stays on your server.">Privacy & terms</Title>
      <Card>
        <Text style={s.h}>Privacy</Text>
        <Text style={s.p}>
          GrantClose is self-hosted software. All data — accounts, grants, expenses, receipt
          photos, and reports — is stored in the database and filesystem of the server you
          deploy it on. No analytics, tracking, or third-party data sharing are built in.
        </Text>
        <Text style={s.p}>
          The only external calls the software can make are the ones you explicitly configure:
          SMTP for outgoing email, and an OpenAI-compatible API for the optional report
          narrative. Leave those unset and the app makes no outbound calls at all.
        </Text>
      </Card>
      <Card>
        <Text style={s.h}>Terms</Text>
        <Text style={s.p}>
          Provided as-is for internal use by your organization. You are responsible for securing
          your deployment (HTTPS, strong JWT_SECRET, regular backups) and for complying with
          your funders' record-keeping requirements.
        </Text>
      </Card>
    </Screen>
  );
}

const s = StyleSheet.create({
  h: { fontSize: 15, fontWeight: '700', color: colors.ink },
  p: { fontSize: 13.5, color: colors.sub, lineHeight: 20 },
});
