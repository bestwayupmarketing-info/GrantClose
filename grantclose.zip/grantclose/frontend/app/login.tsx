import React, { useState } from 'react';
import { StyleSheet, Text } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Screen, Title, Card, Field, Button, ErrorText } from '@/src/components/ui';
import { useAuth } from '@/src/auth';
import { colors, spacing } from '@/constants/theme';

export default function Login() {
  const { signIn } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setError(null);
    setBusy(true);
    try {
      await signIn(email.trim(), password);
      router.replace('/(tabs)');
    } catch (e: any) {
      setError(e.message ?? 'Sign-in failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <Title sub="Welcome back.">Sign in</Title>
      <Card>
        <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="you@org.org" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry placeholder="Your password" />
        <ErrorText message={error} />
        <Button label="Sign in" onPress={submit} loading={busy} />
      </Card>
      <Text style={s.linkRow}>
        New to GrantClose?{' '}
        <Link href="/register" style={s.link}>
          Create an account
        </Link>
      </Text>
      <Text style={s.linkRow}>
        <Link href="/forgot" style={s.link}>
          Forgot your password?
        </Link>
      </Text>
    </Screen>
  );
}

const s = StyleSheet.create({
  linkRow: { textAlign: 'center', color: colors.sub, fontSize: 14 },
  link: { color: colors.primary, fontWeight: '700' },
});
