import React from 'react';
import { StyleSheet, Text, View, Switch } from 'react-native';
import { useState } from 'react';
import { Screen, Title, Card } from '@/src/components/ui';
import { colors } from '@/constants/theme';

export default function Notifications() {
  const [flags, setFlags] = useState({ report: true, budget: true, email: false });
  const items: [keyof typeof flags, string, string][] = [
    ['report', 'Report reminders', 'Nudge me when a grant end date approaches.'],
    ['budget', 'Budget alerts', 'Warn me when a category passes 85% spent.'],
    ['email', 'Email copies', 'Email me a copy of every closeout report (requires SMTP).'],
  ];
  return (
    <Screen>
      <Title sub="Preferences are stored on this device.">Notifications</Title>
      <Card style={{ paddingVertical: 8 }}>
        {items.map(([key, title, sub], i) => (
          <View key={key} style={[s.row, i > 0 && s.border]}>
            <View style={{ flex: 1, marginRight: 12 }}>
              <Text style={s.title}>{title}</Text>
              <Text style={s.sub}>{sub}</Text>
            </View>
            <Switch
              value={flags[key]}
              onValueChange={(v) => setFlags({ ...flags, [key]: v })}
              trackColor={{ true: colors.primary }}
            />
          </View>
        ))}
      </Card>
      <Text style={s.note}>
        Budget alerts are evaluated when you open the app in this self-hosted build.
      </Text>
    </Screen>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12 },
  border: { borderTopWidth: 1, borderTopColor: colors.line },
  title: { fontSize: 15, fontWeight: '600', color: colors.ink },
  sub: { fontSize: 12.5, color: colors.sub, marginTop: 2 },
  note: { fontSize: 12.5, color: colors.sub },
});
