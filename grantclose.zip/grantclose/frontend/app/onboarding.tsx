import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen, Title, Button } from '@/src/components/ui';
import { useAuth } from '@/src/auth';
import { colors, spacing } from '@/constants/theme';

const STEPS = [
  ['1', 'Create a grant', 'Name the funder, the award amount, and your approved budget categories.'],
  ['2', 'Log spending', 'Add expenses with dates, vendors, and receipt photos as you go.'],
  ['3', 'Record outcomes', 'Capture what the funding achieved — numbers and stories.'],
  ['4', 'Close out', 'Generate the printable closeout report and send it to your funder.'],
];

export default function Onboarding() {
  const { user } = useAuth();
  const router = useRouter();

  return (
    <Screen>
      <Title sub={`Let's get ${user?.org_name || 'your organization'} set up.`}>How GrantClose works</Title>
      <View style={s.list}>
        {STEPS.map(([n, t, d]) => (
          <View key={n} style={s.step}>
            <View style={s.badge}>
              <Text style={s.badgeText}>{n}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.stepTitle}>{t}</Text>
              <Text style={s.stepText}>{d}</Text>
            </View>
          </View>
        ))}
      </View>
      <Button label="Create my first grant" onPress={() => router.replace('/grant/new')} />
      <Button label="Explore the dashboard first" variant="ghost" onPress={() => router.replace('/(tabs)')} />
    </Screen>
  );
}

const s = StyleSheet.create({
  list: { gap: spacing(3) },
  step: { flexDirection: 'row', gap: spacing(3), alignItems: 'flex-start' },
  badge: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: { color: '#fff', fontWeight: '800', fontSize: 14 },
  stepTitle: { fontSize: 16, fontWeight: '700', color: colors.ink },
  stepText: { fontSize: 13.5, color: colors.sub, lineHeight: 19, marginTop: 2 },
});
