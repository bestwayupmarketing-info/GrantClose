import React, { useCallback, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { Screen, Title, Card, Field, Button, ErrorText } from '@/src/components/ui';
import { api } from '@/src/api';
import { colors } from '@/constants/theme';
import type { Grant } from '@/src/types';

export default function NewOutcome() {
  const { grantId } = useLocalSearchParams<{ grantId: string }>();
  const router = useRouter();
  const [grants, setGrants] = useState<Grant[]>([]);
  const [grant, setGrant] = useState<Grant | null>(null);
  const [title, setTitle] = useState('');
  const [detail, setDetail] = useState('');
  const [metricValue, setMetricValue] = useState('');
  const [metricUnit, setMetricUnit] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useFocusEffect(
    useCallback(() => {
      api.get<Grant[]>('/api/grants').then((gs) => {
        setGrants(gs);
        setGrant(gs.find((g) => g.id === grantId) ?? gs[0] ?? null);
      }).catch(() => {});
    }, [grantId])
  );

  async function submit() {
    setError(null);
    if (!grant) return setError('Pick a grant first.');
    if (!title.trim()) return setError('Give the outcome a short title.');
    setBusy(true);
    try {
      await api.post(`/api/grants/${grant.id}/outcomes`, {
        title: title.trim(),
        detail,
        metric_value: metricValue ? parseFloat(metricValue) : null,
        metric_unit: metricUnit.trim(),
        date,
      });
      router.replace(`/grant/${grant.id}`);
    } catch (e: any) {
      setError(e.message ?? 'Could not save outcome');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <Title sub="Numbers and stories your funder will ask about.">Add outcome</Title>
      <Card>
        <Text style={s.label}>Grant</Text>
        <View style={s.chipsWrap}>
          {grants.map((g) => (
            <Button
              key={g.id}
              label={g.name}
              small
              variant={grant?.id === g.id ? 'primary' : 'ghost'}
              onPress={() => setGrant(g)}
            />
          ))}
        </View>
        <Field label="Outcome title" value={title} onChangeText={setTitle} placeholder="200 books distributed to families" />
        <Field label="Details (optional)" value={detail} onChangeText={setDetail} multiline placeholder="Story, context, quotes…" />
        <View style={s.twoCol}>
          <View style={{ flex: 1 }}>
            <Field label="Metric value" value={metricValue} onChangeText={setMetricValue} keyboardType="decimal-pad" placeholder="200" />
          </View>
          <View style={{ flex: 1 }}>
            <Field label="Unit" value={metricUnit} onChangeText={setMetricUnit} placeholder="books" />
          </View>
        </View>
        <Field label="Date" value={date} onChangeText={setDate} />
      </Card>
      <ErrorText message={error} />
      <Button label="Save outcome" onPress={submit} loading={busy} disabled={!grant} />
    </Screen>
  );
}

const s = StyleSheet.create({
  label: { fontSize: 13, fontWeight: '600', color: colors.ink },
  chipsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  twoCol: { flexDirection: 'row', gap: 12 },
});
