import React, { useState } from 'react';
import { StyleSheet, Text } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Screen, Title, Card, Field, Button, ErrorText } from '@/src/components/ui';
import { useAuth } from '@/src/auth';
import { colors } from '@/constants/theme';

export default function Register() {
  const { register } = useAuth();
  const router = useRouter();
  const [name, setName] = useState('');
  const [org, setOrg] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setError(null);
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    setBusy(true);
    try {
      await register(name.trim(), email.trim(), password, org.trim());
      router.replace('/onboarding');
    } catch (e: any) {
      setError(e.message ?? 'Registration failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen>
      <Title sub="Free for small teams. Set up in a minute.">Create your account</Title>
      <Card>
        <Field label="Your name" value={name} onChangeText={setName} placeholder="Sam Rivera" />
        <Field label="Organization" value={org} onChangeText={setOrg} placeholder="River Community Fund (optional)" />
        <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="you@org.org" />
        <Field label="Password (8+ characters)" value={password} onChangeText={setPassword} secureTextEntry placeholder="Choose a password" />
        <ErrorText message={error} />
        <Button label="Create account" onPress={submit} loading={busy} />
      </Card>
      <Text style={s.linkRow}>
        Already registered?{' '}
        <Link href="/login" style={s.link}>
          Sign in
        </Link>
      </Text>
      <Text style={s.fine}>
        By continuing you agree to the{' '}
        <Link href="/legal" style={s.link}>
          privacy note &amp; terms
        </Link>
        .
      </Text>
    </Screen>
  );
}

const s = StyleSheet.create({
  linkRow: { textAlign: 'center', color: colors.sub, fontSize: 14 },
  link: { color: colors.primary, fontWeight: '700' },
  fine: { textAlign: 'center', color: colors.sub, fontSize: 12, marginTop: 4 },
});
