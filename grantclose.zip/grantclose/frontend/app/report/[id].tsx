import React, { useCallback, useState } from 'react';
import { Platform, StyleSheet, Text, View, Linking } from 'react-native';
import { useFocusEffect, useLocalSearchParams } from 'expo-router';
import { Screen, Title, Card, Button, ErrorText } from '@/src/components/ui';
import { api, apiUrl, getToken } from '@/src/api';
import { money } from '@/src/format';
import { colors } from '@/constants/theme';
import type { Grant } from '@/src/types';

export default function ReportView() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [grant, setGrant] = useState<Grant | null>(null);
  const [narrative, setNarrative] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyAi, setBusyAi] = useState(false);

  useFocusEffect(
    useCallback(() => {
      if (!id) return;
      api.get<Grant>(`/api/grants/${id}`).then(setGrant).catch((e) => setError(e.message));
    }, [id])
  );

  if (!id) return <Screen><ErrorText message="Missing grant id" /></Screen>;

  const reportUrl = `${apiUrl(`/api/grants/${id}/report`)}?token=${encodeURIComponent(getToken() ?? '')}`;

  async function generateNarrative() {
    setBusyAi(true);
    setError(null);
    try {
      const r = await api.post<{ summary: string }>(`/api/grants/${id}/ai-summary`);
      setNarrative(r.summary);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusyAi(false);
    }
  }

  function openReport() {
    if (Platform.OS === 'web') {
      window.open(reportUrl, '_blank');
    } else {
      Linking.openURL(reportUrl);
    }
  }

  return (
    <Screen>
      <Title sub={grant ? `${grant.name} — ready for your funder` : 'Closeout report'}>Closeout report</Title>
      <ErrorText message={error} />

      {grant?.summary && (
        <Card>
          <Text style={s.statLine}>
            {money(grant.summary.total_spent)} spent of {money(grant.summary.total_budgeted)} ·{' '}
            {money(grant.summary.total_remaining)} remaining
          </Text>
          <Text style={s.hint}>
            The report includes budget vs. actual, the full expense ledger, and your recorded
            outcomes.
          </Text>
        </Card>
      )}

      <Card>
        <Button label="Open printable report ↗" onPress={openReport} />
        <Text style={s.hint}>
          Opens in a new tab with a Print / Save-as-PDF button — that file is what you send to
          your funder.
        </Text>
      </Card>

      <Card>
        <Text style={s.sectionTitle}>AI narrative (optional)</Text>
        <Text style={s.hint}>
          Generates 2-3 paragraphs summarizing performance for the report cover email. Uses your
          configured AI key, or a built-in template.
        </Text>
        <Button label={narrative ? 'Regenerate narrative' : 'Generate narrative'} variant="ghost" onPress={generateNarrative} loading={busyAi} />
        {narrative && (
          <View style={s.narrativeBox}>
            <Text style={s.narrative}>{narrative}</Text>
          </View>
        )}
      </Card>
    </Screen>
  );
}

const s = StyleSheet.create({
  statLine: { fontSize: 15, fontWeight: '700', color: colors.ink },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: colors.ink },
  hint: { fontSize: 13, color: colors.sub, lineHeight: 19 },
  narrativeBox: { backgroundColor: colors.primarySoft, borderRadius: 12, padding: 12 },
  narrative: { fontSize: 14, color: colors.ink, lineHeight: 21 },
});
