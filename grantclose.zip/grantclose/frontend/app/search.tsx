import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen, Title, Card, Field, EmptyState } from '@/src/components/ui';
import { api } from '@/src/api';
import { money, shortDate } from '@/src/format';
import type { Expense, Grant } from '@/src/types';
import { colors } from '@/constants/theme';

type Hit = { kind: 'grant'; grant: Grant } | { kind: 'expense'; grant: Grant; expense: Expense };

export default function Search() {
  const router = useRouter();
  const [q, setQ] = useState('');
  const [grants, setGrants] = useState<Grant[]>([]);
  const [expenses, setExpenses] = useState<Map<string, Expense[]>>(new Map());

  useEffect(() => {
    api.get<Grant[]>('/api/grants').then(async (gs) => {
      setGrants(gs);
      const m = new Map<string, Expense[]>();
      await Promise.all(
        gs.map(async (g) => {
          m.set(g.id, await api.get<Expense[]>(`/api/grants/${g.id}/expenses`));
        })
      );
      setExpenses(m);
    }).catch(() => {});
  }, []);

  const hits = useMemo<Hit[]>(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return [];
    const out: Hit[] = [];
    for (const g of grants) {
      if (`${g.name} ${g.funder}`.toLowerCase().includes(needle)) out.push({ kind: 'grant', grant: g });
      for (const e of expenses.get(g.id) ?? []) {
        if (`${e.vendor} ${e.description} ${e.category}`.toLowerCase().includes(needle)) {
          out.push({ kind: 'expense', grant: g, expense: e });
        }
      }
    }
    return out.slice(0, 50);
  }, [q, grants, expenses]);

  return (
    <Screen>
      <Title sub="Search grants, vendors, and expense descriptions.">Search</Title>
      <Field label="Search" value={q} onChangeText={setQ} placeholder="e.g. bookstore, city council…" autoFocus />
      {q.trim() && hits.length === 0 && (
        <EmptyState title="No matches" hint="Try a different keyword." />
      )}
      {hits.map((h, i) =>
        h.kind === 'grant' ? (
          <Pressable key={`g${i}`} onPress={() => router.push(`/grant/${h.grant.id}`)}>
            <Card style={{ paddingVertical: 12 }}>
              <Text style={s.kind}>GRANT</Text>
              <Text style={s.title}>{h.grant.name}</Text>
              <Text style={s.meta}>
                {h.grant.funder} · {money(h.grant.summary?.total_spent ?? 0)} spent
              </Text>
            </Card>
          </Pressable>
        ) : (
          <Pressable key={`e${i}`} onPress={() => router.push(`/grant/${h.grant.id}`)}>
            <Card style={{ paddingVertical: 12 }}>
              <Text style={s.kind}>EXPENSE</Text>
              <Text style={s.title}>
                {h.expense.vendor || h.expense.description || 'Expense'} · {money(h.expense.amount)}
              </Text>
              <Text style={s.meta}>
                {h.grant.name} · {shortDate(h.expense.date)} · {h.expense.category}
              </Text>
            </Card>
          </Pressable>
        )
      )}
    </Screen>
  );
}

const s = StyleSheet.create({
  kind: { fontSize: 10, fontWeight: '800', color: colors.primary, letterSpacing: 1 },
  title: { fontSize: 15, fontWeight: '700', color: colors.ink },
  meta: { fontSize: 12.5, color: colors.sub },
});
