import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { Screen, Title, Card } from '@/src/components/ui';
import { useAuth } from '@/src/auth';
import { colors } from '@/constants/theme';

export default function Team() {
  const { user } = useAuth();
  return (
    <Screen>
      <Title sub="People with access to this workspace.">Team</Title>
      <Card>
        <Text style={s.name}>{user?.name} (you)</Text>
        <Text style={s.meta}>{user?.email} · Owner</Text>
      </Card>
      <Card>
        <Text style={s.title}>Invite teammates</Text>
        <Text style={s.body}>
          This self-hosted build is single-tenant: create additional accounts for colleagues on
          the same server, or share one login for a small club. Multi-user workspaces per grant
          are on the roadmap.
        </Text>
      </Card>
    </Screen>
  );
}

const s = StyleSheet.create({
  name: { fontSize: 15, fontWeight: '700', color: colors.ink },
  meta: { fontSize: 13, color: colors.sub },
  title: { fontSize: 15, fontWeight: '700', color: colors.ink },
  body: { fontSize: 13.5, color: colors.sub, lineHeight: 20 },
});
