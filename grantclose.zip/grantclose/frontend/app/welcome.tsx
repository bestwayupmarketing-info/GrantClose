import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { Link } from 'expo-router';
import { Screen, Button } from '@/src/components/ui';
import { colors, spacing } from '@/constants/theme';

export default function Welcome() {
  return (
    <Screen scroll={false}>
      <View style={s.hero}>
        <Image source={require('@/assets/icon.png')} style={s.logo} />
        <Text style={s.h1}>GrantClose</Text>
        <Text style={s.tag}>
          Grant reporting for small nonprofits, school clubs, and community groups. Track the
          budget, snap receipts, record outcomes, and generate a funder-ready closeout report.
        </Text>
      </View>

      <View style={s.features}>
        {[
          ['Budget tracking', 'Enter approved categories and watch spending against them in real time.'],
          ['Receipt photos', 'Attach receipt photos to every expense so nothing gets lost.'],
          ['Closeout reports', 'One click generates a clean, printable report for your funder.'],
        ].map(([t, d]) => (
          <View key={t} style={s.feature}>
            <Text style={s.featureTitle}>{t}</Text>
            <Text style={s.featureText}>{d}</Text>
          </View>
        ))}
      </View>

      <Link href="/register" asChild>
        <Button label="Create free account" onPress={() => {}} />
      </Link>
      <Link href="/login" asChild>
        <Button label="I already have an account" variant="ghost" onPress={() => {}} />
      </Link>
      <Text style={s.foot}>Self-hosted, open code, no lock-in. Your data stays yours.</Text>
    </Screen>
  );
}

const s = StyleSheet.create({
  hero: { alignItems: 'center', marginTop: spacing(10), marginBottom: spacing(6), gap: spacing(3) },
  logo: { width: 84, height: 84, borderRadius: 20 },
  h1: { fontSize: 34, fontWeight: '800', color: colors.ink },
  tag: { fontSize: 15, color: colors.sub, textAlign: 'center', lineHeight: 22, maxWidth: 420 },
  features: { gap: spacing(3), marginBottom: spacing(6) },
  feature: {
    backgroundColor: colors.card,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
    padding: spacing(4),
    gap: 4,
  },
  featureTitle: { fontSize: 15, fontWeight: '700', color: colors.primaryDark },
  featureText: { fontSize: 13.5, color: colors.sub, lineHeight: 19 },
  foot: { textAlign: 'center', fontSize: 12, color: colors.sub, marginTop: spacing(2) },
});
