export const colors = {
  primary: '#0f766e',
  primaryDark: '#115e59',
  primarySoft: '#ccfbf1',
  bg: '#f6f8f7',
  card: '#ffffff',
  ink: '#1a2332',
  sub: '#64748b',
  line: '#e2e8f0',
  danger: '#dc2626',
  dangerSoft: '#fee2e2',
  warn: '#b45309',
  warnSoft: '#fef3c7',
  ok: '#15803d',
  okSoft: '#dcfce7',
};

export const spacing = (n: number) => n * 4;

export const radius = { sm: 8, md: 12, lg: 16, pill: 999 };
