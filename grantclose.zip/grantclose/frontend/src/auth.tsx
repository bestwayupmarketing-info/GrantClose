import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { api, setToken } from './api';

export type User = {
  id: string;
  email: string;
  name: string;
  org_name: string;
};

type AuthCtx = {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, org: string) => Promise<void>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
};

const Ctx = createContext<AuthCtx>({
  user: null,
  loading: true,
  signIn: async () => {},
  register: async () => {},
  signOut: async () => {},
  refresh: async () => {},
});

const TOKEN_KEY = 'gc.token';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const token = await AsyncStorage.getItem(TOKEN_KEY);
        if (token) {
          setToken(token);
          const me = await api.get<User>('/api/auth/me');
          setUser(me);
        }
      } catch {
        await AsyncStorage.removeItem(TOKEN_KEY);
        setToken(null);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const finishAuth = useCallback(async (token: string, u: User) => {
    await AsyncStorage.setItem(TOKEN_KEY, token);
    setToken(token);
    setUser(u);
  }, []);

  const signIn = useCallback(
    async (email: string, password: string) => {
      const r = await api.post<{ token: string; user: User }>('/api/auth/login', {
        email,
        password,
      });
      await finishAuth(r.token, r.user);
    },
    [finishAuth]
  );

  const register = useCallback(
    async (name: string, email: string, password: string, org: string) => {
      const r = await api.post<{ token: string; user: User }>('/api/auth/register', {
        name,
        email,
        password,
        org_name: org,
      });
      await finishAuth(r.token, r.user);
    },
    [finishAuth]
  );

  const signOut = useCallback(async () => {
    await AsyncStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setUser(null);
  }, []);

  const refresh = useCallback(async () => {
    try {
      setUser(await api.get<User>('/api/auth/me'));
    } catch {
      /* keep cached profile */
    }
  }, []);

  const value = useMemo(
    () => ({ user, loading, signIn, register, signOut, refresh }),
    [user, loading, signIn, register, signOut, refresh]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}
