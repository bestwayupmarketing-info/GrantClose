import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing } from '@/constants/theme';
import { pct } from '@/src/format';

export function Screen({ children, scroll = true }: { children: React.ReactNode; scroll?: boolean }) {
  const inner = scroll ? (
    <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
      {children}
    </ScrollView>
  ) : (
    <View style={s.scroll}>{children}</View>
  );
  return (
    <SafeAreaView style={s.safe} edges={['top', 'bottom']}>
      {inner}
    </SafeAreaView>
  );
}

export function Title({ children, sub }: { children: React.ReactNode; sub?: string }) {
  return (
    <View style={s.titleBlock}>
      <Text style={s.title}>{children}</Text>
      {sub ? <Text style={s.subtitle}>{sub}</Text> : null}
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[s.card, style]}>{children}</View>;
}

type BtnProps = {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'ghost' | 'danger';
  loading?: boolean;
  disabled?: boolean;
  small?: boolean;
};

export function Button({ label, onPress, variant = 'primary', loading, disabled, small }: BtnProps) {
  const bg =
    variant === 'primary' ? colors.primary : variant === 'danger' ? colors.danger : 'transparent';
  const fg = variant === 'ghost' ? colors.primary : '#fff';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        s.btn,
        small && s.btnSmall,
        { backgroundColor: bg },
        variant === 'ghost' && s.btnGhost,
        (pressed || disabled) && { opacity: 0.7 },
      ]}
    >
      {loading ? <ActivityIndicator color={fg} /> : <Text style={[s.btnText, small && s.btnSmallText, { color: fg }]}>{label}</Text>}
    </Pressable>
  );
}

export function Field(props: TextInputProps & { label: string }) {
  const { label, style, ...rest } = props;
  return (
    <View style={s.field}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.sub}
        style={[s.input, style]}
        {...rest}
      />
    </View>
  );
}

export function ProgressBar({ spent, budget }: { spent: number; budget: number }) {
  const p = pct(spent, budget);
  const over = budget > 0 && spent > budget;
  return (
    <View style={s.track}>
      <View
        style={[
          s.fill,
          { width: `${p}%` },
          over && { backgroundColor: colors.danger },
          !over && p > 85 && { backgroundColor: colors.warn },
        ]}
      />
    </View>
  );
}

export function Chip({ label, tone = 'soft' }: { label: string; tone?: 'soft' | 'ok' | 'warn' | 'danger' }) {
  const bg = tone === 'ok' ? colors.okSoft : tone === 'warn' ? colors.warnSoft : tone === 'danger' ? colors.dangerSoft : colors.primarySoft;
  const fg = tone === 'ok' ? colors.ok : tone === 'warn' ? colors.warn : tone === 'danger' ? colors.danger : colors.primaryDark;
  return (
    <View style={[s.chip, { backgroundColor: bg }]}>
      <Text style={[s.chipText, { color: fg }]}>{label}</Text>
    </View>
  );
}

export function EmptyState({ title, hint }: { title: string; hint: string }) {
  return (
    <Card style={s.empty}>
      <Text style={s.emptyTitle}>{title}</Text>
      <Text style={s.emptyHint}>{hint}</Text>
    </Card>
  );
}

export function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <View style={s.row}>
      <Text style={s.rowLabel}>{label}</Text>
      <Text style={[s.rowValue, strong && { fontWeight: '700', color: colors.ink }]}>{value}</Text>
    </View>
  );
}

export function ErrorText({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <View style={s.errorBox}>
      <Text style={s.errorText}>{message}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  scroll: { padding: spacing(5), paddingBottom: spacing(10), gap: spacing(3) },
  titleBlock: { marginBottom: spacing(1) },
  title: { fontSize: 26, fontWeight: '800', color: colors.ink },
  subtitle: { fontSize: 14, color: colors.sub, marginTop: 2 },
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing(4),
    borderWidth: 1,
    borderColor: colors.line,
    gap: spacing(2),
  },
  btn: {
    borderRadius: radius.md,
    paddingVertical: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnSmall: { paddingVertical: 8, paddingHorizontal: 14, alignSelf: 'flex-start' },
  btnGhost: { borderWidth: 1, borderColor: colors.primary },
  btnText: { fontSize: 15, fontWeight: '700' },
  btnSmallText: { fontSize: 13 },
  field: { gap: 6 },
  label: { fontSize: 13, fontWeight: '600', color: colors.ink },
  input: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 15,
    color: colors.ink,
  },
  track: { height: 8, borderRadius: 99, backgroundColor: colors.line, overflow: 'hidden' },
  fill: { height: 8, borderRadius: 99, backgroundColor: colors.primary, minWidth: 4 },
  chip: { alignSelf: 'flex-start', borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 3 },
  chipText: { fontSize: 12, fontWeight: '700' },
  empty: { alignItems: 'center', paddingVertical: spacing(8) },
  emptyTitle: { fontSize: 16, fontWeight: '700', color: colors.ink },
  emptyHint: { fontSize: 13, color: colors.sub, textAlign: 'center' },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  rowLabel: { color: colors.sub, fontSize: 14 },
  rowValue: { color: colors.ink, fontSize: 14, fontWeight: '500' },
  errorBox: {
    backgroundColor: colors.dangerSoft,
    borderRadius: radius.md,
    padding: spacing(3),
  },
  errorText: { color: colors.danger, fontSize: 13, fontWeight: '600' },
});
