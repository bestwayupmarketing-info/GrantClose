export type Category = { name: string; budgeted: number; spent?: number; remaining?: number };

export type Grant = {
  id: string;
  name: string;
  funder: string;
  amount_total: number;
  start_date?: string | null;
  end_date?: string | null;
  notes?: string;
  categories?: Category[];
  status: 'active' | 'closed';
  created_at: string;
  summary?: {
    categories: Category[];
    total_budgeted: number;
    total_spent: number;
    total_remaining: number;
    uncategorized_spent: number;
  };
};

export type Expense = {
  id: string;
  grant_id: string;
  category: string;
  amount: number;
  date: string;
  vendor: string;
  description: string;
  receipt_file?: string | null;
};

export type Outcome = {
  id: string;
  grant_id: string;
  title: string;
  detail: string;
  metric_value?: number | null;
  metric_unit?: string;
  date?: string;
};
